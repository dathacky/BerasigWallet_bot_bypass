"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[2160], {
    82160: function(e, t, a) {
        a.d(t, {
            Z: function() {
                return C
            }
        });
        var s = a(45615)
          , r = a(48278)
          , l = a(81647)
          , i = a(13352)
          , n = a(94224)
          , d = a(74880);
        let o = i.forwardRef(function(e, t) {
            let {title: a, titleId: s, ...r} = e;
            return i.createElement("svg", Object.assign({
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                strokeWidth: 1.5,
                stroke: "currentColor",
                "aria-hidden": "true",
                "data-slot": "icon",
                ref: t,
                "aria-labelledby": s
            }, r), a ? i.createElement("title", {
                id: s
            }, a) : null, i.createElement("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 1 1-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 0 0 4.486-6.336l-3.276 3.277a3.004 3.004 0 0 1-2.25-2.25l3.276-3.276a4.5 4.5 0 0 0-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085m-1.745 1.437L5.909 7.5H4.5L2.25 3.75l1.5-1.5L7.5 4.5v1.409l4.26 4.26m-1.745 1.437 1.745-1.437m6.615 8.206L15.75 15.75M4.867 19.125h.008v.008h-.008v-.008Z"
            }))
        });
        var c = a(96846)
          , A = a(28118)
          , h = a(89305)
          , u = a(92598)
          , f = a(99638)
          , m = a(52225)
          , x = a(6059)
          , g = a(60070)
          , b = a(70978)
          , v = a(94027)
          , p = a(64545)
          , w = a(15574)
          , j = a(11976)
          , N = {
            src: "/_next/static/media/bear-catch-bee.1cfcc2d3.png",
            height: 108,
            width: 108,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABAklEQVR42mOAga3pJjPOTLA//WSt17QdSdYrNiRZ6oElFkzr9e7ozBXb3Oi+aWuyxf9Ls33/X5/k8r+VQUEXrGBhW2zzgmIG9/1TKo8fntf3f19/xf93u5zvKfJ5yUw1YuBngIH19f4LLq+o/X9uksefC9Otf8/vnfBrWX/XFYa1ibby00MMV11dbPJl+aZt/+9sKfr3apnwv91LZv7fvm3/XQYTBnGLDan6724scPt/d3Pqv+uLgv4/Xev0/+H6hF/9k5avZICBXS22u67Osfp/dpLzt1211v92NRtPZGBwUWO4mm3DAnasn/6WWT56C5fE63bMtNN8xcDAwMHAwMAAAD5vdOL4CX3kAAAAAElFTkSuQmCC",
            blurWidth: 8,
            blurHeight: 8
        }
          , E = {
            src: "/_next/static/media/bear-friend.0d99f80a.png",
            height: 108,
            width: 108,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABB0lEQVR42mPABlanhm/bmxR8Y01mRBPDmTnFoVfn53e8WZMecnZVtfqNIH3BJfFB95blJf3fGe29luFoX0LKiSnp/28uL/p/oi/l9+Gi0AdbGwv+r6vP+b8vzmcBw/VtxfaHZ6T82D8t+//5JQUXtvnafdtWl/P/6MLe/3szwz8yLI/RP3Cgwe/r0a6g/4sy7Hp7zPS+rKjO+rt3WvP/HaHOPxg6DRhK76zN/be3I/D/Yg+DG5sS/P7Pq8v6PzMr4v8EW/1TEFcX2b9cnmr4f36Y9ZuVPvZ3Joa4LFrgZf0vRVlWkeFApa3ZnGj9bR2hOqfmxxusnxunu3x/qU7e9HC97XvKzFQABI9//+iBuOoAAAAASUVORK5CYII=",
            blurWidth: 8,
            blurHeight: 8
        }
          , Z = a(21440)
          , C = e=>{
            let {disabled: t=!1} = e
              , [a,C] = (0,
            i.useState)(!1)
              , B = (0,
            d.useRouter)()
              , {data: z} = (0,
            x.a)()
              , {data: L} = (0,
            b.Af)(z.guild);
            return (0,
            s.jsxs)("div", {
                className: "flex flex-row items-center",
                children: [(0,
                s.jsxs)(l.default, {
                    href: t ? "" : "/settings",
                    className: (0,
                    n.Z)("flex flex-1 flex-row gap-2 items-center", {
                        "pointer-events-none": t,
                        "cursor-pointer": !t
                    }),
                    children: [(0,
                    s.jsx)(f.Z, {}), (0,
                    s.jsxs)("div", {
                        className: "flex flex-col gap-1",
                        children: [(0,
                        s.jsx)("p", {
                            className: "font-bold",
                            children: z.name
                        }), (0,
                        s.jsx)(u.Z, {
                            user: z
                        })]
                    })]
                }), (0,
                s.jsxs)("div", {
                    className: "flex flex-row gap-2",
                    children: [(0,
                    s.jsxs)("div", {
                        className: "relative cursor-pointer",
                        onClick: ()=>C(!0),
                        children: [(0,
                        s.jsx)(r.default, {
                            className: "absolute w-9 h-9 top-[-1px] left-[-2px]",
                            src: v.Z,
                            alt: "coin"
                        }), (0,
                        s.jsx)("div", {
                            className: "flex h-8 rounded-2xl bg-[#C16240] border items-center justify-end",
                            children: (0,
                            s.jsx)("p", {
                                className: "text-white font-bold pr-2 pl-10",
                                children: (0,
                                g.CE)(z.tokenBalance)
                            })
                        })]
                    }), !!z.isAdmin && (0,
                    s.jsx)("div", {
                        children: (0,
                        s.jsx)("button", {
                            className: "flex items-center justify-center h-8 w-8 bg-[#F1A025] rounded-full border ",
                            onClick: ()=>B.push("/home/admin"),
                            children: (0,
                            s.jsx)(o, {
                                className: "w-5"
                            })
                        })
                    }), (0,
                    s.jsx)("div", {
                        children: (0,
                        s.jsx)(h.Z, {
                            children: (0,
                            s.jsx)("button", {
                                className: "flex items-center justify-center h-8 w-8 bg-[#F1A025] rounded-full border ",
                                children: (0,
                                s.jsx)(c.Z, {
                                    className: "w-5 text-white"
                                })
                            })
                        })
                    })]
                }), (0,
                s.jsx)(m.Z, {
                    open: a,
                    onClose: ()=>C(!1),
                    children: (0,
                    s.jsxs)("div", {
                        className: "flex flex-col gap-4",
                        children: [(0,
                        s.jsxs)("div", {
                            className: "flex flex-col gap-1 items-center text-center",
                            children: [(0,
                            s.jsx)(r.default, {
                                src: p.Z,
                                alt: "funds",
                                width: 64
                            }), (0,
                            s.jsx)("h5", {
                                className: "font-bold",
                                children: "Personal Asset Summary"
                            }), (0,
                            s.jsx)("span", {
                                className: "font-medium",
                                children: "Effortless asset tracking and management view a summary of your claimed assets here."
                            })]
                        }), (0,
                        s.jsxs)("div", {
                            className: "card flex-col gap-3",
                            children: [(0,
                            s.jsxs)("div", {
                                className: "flex flex-row gap-2 items-center",
                                children: [(0,
                                s.jsx)(r.default, {
                                    width: 36,
                                    height: 36,
                                    src: w.Z,
                                    alt: "guild"
                                }), (0,
                                s.jsx)("span", {
                                    className: "font-bold flex-1",
                                    children: "Claimed BEE"
                                }), (0,
                                s.jsx)("p", {
                                    className: "font-bold text-primary",
                                    children: (0,
                                    g.CE)(z.totalTokenClaimed)
                                }), (0,
                                s.jsx)(r.default, {
                                    src: v.Z,
                                    alt: "coin",
                                    className: "w-4 h-4"
                                })]
                            }), (0,
                            s.jsx)("div", {
                                className: "border-t border-border"
                            }), (0,
                            s.jsxs)("div", {
                                className: "flex flex-row gap-2 items-center",
                                children: [(0,
                                s.jsx)(r.default, {
                                    width: 36,
                                    height: 36,
                                    src: j.Z,
                                    alt: "guild"
                                }), (0,
                                s.jsx)("span", {
                                    className: "font-bold flex-1",
                                    children: "Steal"
                                }), (0,
                                s.jsx)("p", {
                                    className: "font-bold text-primary",
                                    children: (0,
                                    g.CE)(z.totalTokenStolen)
                                }), (0,
                                s.jsx)(r.default, {
                                    src: v.Z,
                                    alt: "coin",
                                    className: "w-4 h-4"
                                })]
                            }), (0,
                            s.jsx)("div", {
                                className: "border-t border-border"
                            }), (0,
                            s.jsxs)("div", {
                                className: "flex flex-row gap-2 items-center",
                                children: [(0,
                                s.jsx)(r.default, {
                                    width: 36,
                                    height: 36,
                                    src: N,
                                    alt: "guild"
                                }), (0,
                                s.jsx)("span", {
                                    className: "font-bold flex-1",
                                    children: "Bee Caught"
                                }), (0,
                                s.jsx)("p", {
                                    className: "font-bold text-primary",
                                    children: (0,
                                    g.CE)(z.takeTokenTotal)
                                }), (0,
                                s.jsx)(r.default, {
                                    src: v.Z,
                                    alt: "coin",
                                    className: "w-4 h-4"
                                })]
                            }), (0,
                            s.jsx)("div", {
                                className: "border-t border-border"
                            }), (0,
                            s.jsxs)("div", {
                                className: "flex flex-row gap-2 items-center",
                                children: [(0,
                                s.jsx)(r.default, {
                                    width: 36,
                                    height: 36,
                                    src: E,
                                    alt: "guild"
                                }), (0,
                                s.jsx)("span", {
                                    className: "font-bold flex-1",
                                    children: "Referrals"
                                }), (0,
                                s.jsx)("p", {
                                    className: "font-bold text-primary",
                                    children: (0,
                                    g.CE)(z.totalTokenBonus)
                                }), (0,
                                s.jsx)(r.default, {
                                    src: v.Z,
                                    alt: "coin",
                                    className: "w-4 h-4"
                                })]
                            }), L.owner === z._id && (0,
                            s.jsxs)(i.Fragment, {
                                children: [(0,
                                s.jsx)("div", {
                                    className: "border-t border-border"
                                }), (0,
                                s.jsxs)("div", {
                                    className: "flex flex-row gap-2 items-center",
                                    children: [(0,
                                    s.jsx)(r.default, {
                                        width: 36,
                                        height: 36,
                                        src: Z.Z,
                                        alt: "guild"
                                    }), (0,
                                    s.jsx)("span", {
                                        className: "font-bold ",
                                        children: "Guild Commission"
                                    }), (0,
                                    s.jsxs)("div", {
                                        className: "flex-1 dropdown dropdown-top dropdown-end",
                                        children: [(0,
                                        s.jsx)("label", {
                                            tabIndex: 0,
                                            children: (0,
                                            s.jsx)(A.Z, {
                                                className: "w-4 h-4 cursor-pointer"
                                            })
                                        }), (0,
                                        s.jsx)("div", {
                                            tabIndex: 0,
                                            className: "dropdown-content z-[1] menu p-2 border border-border bg-card rounded-2xl w-52 text-center",
                                            children: "Receive 1% of BEE contributed by members."
                                        })]
                                    }), (0,
                                    s.jsx)("p", {
                                        className: "font-bold text-primary",
                                        children: (0,
                                        g.CE)(.01 * L.totalToken)
                                    }), (0,
                                    s.jsx)(r.default, {
                                        src: v.Z,
                                        alt: "coin",
                                        className: "w-4 h-4"
                                    })]
                                })]
                            })]
                        })]
                    })
                })]
            })
        }
    },
    52225: function(e, t, a) {
        var s = a(45615)
          , r = a(94224);
        let l = {
            right: "translate-x-0",
            left: "translate-x-0",
            top: "translate-y-0",
            bottom: "translate-y-0"
        }
          , i = {
            right: "translate-x-full",
            left: "-translate-x-full",
            top: "-translate-y-full",
            bottom: "translate-y-full"
        }
          , n = {
            right: "inset-y-0 right-0",
            left: "inset-y-0 left-0",
            top: "inset-x-0 top-0",
            bottom: "inset-x-0 bottom-0"
        }
          , d = {
            right: "rounded-l-[20px]",
            left: "rounded-r-[20px]",
            top: "rounded-b-[20px]",
            bottom: "rounded-t-[20px]"
        };
        t.Z = e=>{
            let {open: t, onClose: a, placement: o="bottom", children: c} = e;
            return (0,
            s.jsxs)("div", {
                id: "dialog-".concat(o),
                className: "relative z-[1000]",
                "aria-labelledby": "slide-over",
                role: "dialog",
                "aria-modal": "true",
                onClick: a,
                children: [(0,
                s.jsx)("div", {
                    className: (0,
                    r.W)("fixed inset-0 bg-[#0006] bg-opacity-75 transition-all", {
                        "opacity-100 duration-500 ease-in-out visible": t
                    }, {
                        "opacity-0 duration-500 ease-in-out invisible": !t
                    })
                }), (0,
                s.jsx)("div", {
                    className: (0,
                    r.W)({
                        "fixed inset-0 overflow-hidden": t
                    }),
                    children: (0,
                    s.jsx)("div", {
                        className: "absolute inset-0 overflow-hidden",
                        children: (0,
                        s.jsx)("div", {
                            className: (0,
                            r.W)("pointer-events-none fixed max-w-full", n[o]),
                            children: (0,
                            s.jsx)("div", {
                                className: (0,
                                r.W)("pointer-events-auto relative w-full h-full transform transition ease-in-out duration-500", {
                                    [i[o]]: !t
                                }, {
                                    [l[o]]: t
                                }),
                                onClick: e=>{
                                    e.preventDefault(),
                                    e.stopPropagation()
                                }
                                ,
                                children: (0,
                                s.jsx)("div", {
                                    className: (0,
                                    r.W)("h-full bg-body p-4 overflow-y-scroll", d[o], {
                                        "shadow-[0_-15px_39px_0px_#C16240] hidden": t
                                    }),
                                    children: t ? c : null
                                })
                            })
                        })
                    })
                })]
            })
        }
    },
    89305: function(e, t, a) {
        a.d(t, {
            Z: function() {
                return A
            }
        });
        var s = a(45615)
          , r = a(13352)
          , l = a(46182)
          , i = a(52225)
          , n = a(11363)
          , d = a(80526)
          , o = a(6059)
          , c = a(59116);
        function A(e) {
            let {children: t, userId: a} = e
              , [A,h] = (0,
            r.useState)(!1)
              , u = (0,
            o.a)(a)
              , {message: f} = (0,
            c.p)();
            return (0,
            s.jsxs)(r.Fragment, {
                children: [(0,
                s.jsx)("div", {
                    onClick: ()=>h(!0),
                    children: t
                }), (0,
                s.jsx)(i.Z, {
                    open: A,
                    placement: "bottom",
                    onClose: ()=>h(!1),
                    children: (0,
                    s.jsxs)("div", {
                        className: "flex flex-col items-center gap-4",
                        children: [(0,
                        s.jsx)("h5", {
                            children: u.data.name
                        }), (0,
                        s.jsxs)("div", {
                            className: "flex flex-row gap-1",
                            children: [(0,
                            d.Sy)(u.data.address, {
                                maxLength: 4
                            }), (0,
                            s.jsx)(n.S, {
                                className: "w-4",
                                content: u.data.address,
                                onClick: ()=>{
                                    f({
                                        msg: "Copy to clipboard",
                                        type: "success"
                                    })
                                }
                            })]
                        }), (0,
                        s.jsx)(l.ZP, {
                            value: "address"
                        }), (0,
                        s.jsx)("span", {
                            className: "text-secondary",
                            children: "Use this QR code to receive tokens on Berachain"
                        })]
                    })
                })]
            })
        }
    },
    92598: function(e, t, a) {
        a.d(t, {
            Z: function() {
                return l
            }
        });
        var s = a(45615);
        a(13352);
        var r = a(71203);
        function l(e) {
            let {user: t} = e
              , a = (0,
            r.d)(t);
            return (0,
            s.jsxs)("p", {
                children: ["Level ", a]
            })
        }
    },
    99638: function(e, t, a) {
        a.d(t, {
            Z: function() {
                return p
            }
        });
        var s, r, l = a(45615), i = a(13352), n = a(48278), d = a(92725), o = a(6059), c = {
            src: "/_next/static/media/wood.9d91afc7.svg",
            height: 53,
            width: 52,
            blurWidth: 0,
            blurHeight: 0
        }, A = {
            src: "/_next/static/media/bronze.5d7a8877.svg",
            height: 53,
            width: 53,
            blurWidth: 0,
            blurHeight: 0
        }, h = {
            src: "/_next/static/media/gold.450dc96b.svg",
            height: 53,
            width: 53,
            blurWidth: 0,
            blurHeight: 0
        }, u = {
            src: "/_next/static/media/ruby.62e7d3df.svg",
            height: 53,
            width: 53,
            blurWidth: 0,
            blurHeight: 0
        }, f = {
            src: "/_next/static/media/wood.f8650773.png",
            height: 71,
            width: 71,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AW4sJACS1NwEmmdBgx8gFVEREQsH9fT4yL6yznhUXjvhAQAAAATBjVe4IB8VQxQSDAAEAwEA8/X6APj4+uoZFw5BAeWuaIMFBAN8DgwH+vb5/QTU4fEBGg8E+xsXDgb3+PvPAe2zZtQCAQAr7/D4/v4PCALT2OoA++32AEM6H/4AAQACAeyuXdrx8/sl5vjw/xUWBwHY1PQArKPjAG1tKf8hGg0BAeanU5/6+/5g5u70+gYPBwbj5vkA9uv1/TsyFgPO1e3nAd6eShkEAv/KAgEBHP3+///8/v4ACQYEAdbe8wC+w+tQAemlSAADAf0j4Of4o+zv+zkHBgIA5ur65NXY9Wr5+f2z01l/aBSfLNUAAAAASUVORK5CYII=",
            blurWidth: 8,
            blurHeight: 8
        }, m = {
            src: "/_next/static/media/bronze.1753719c.png",
            height: 73,
            width: 74,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBUlEQVR42mP4+ew0MwMU/P/1tfj3vV2r/r3fygnifztcwwqR+P+f8ffjo3M+np73/9XO/P+fdhff/LozzgAs+fXODoWfN9ZeeL275P/lNUF/bmzJ+nVvc+z/D9vS/n/alZ7H8Gl/ReynnVn/b61y/Hmpw+r/pSrr//cWWf16ti7+/9fdmdcZPq0zE/q4M/P5nYWO/49Wqv3bWWr+/3q7xJ8na2L//9ifXQq25svurNVP1kX9P9+r/PNcm9SfM5Pt/33YkfHr665UTbCCz7vSwz9sT/v/YHn4/ytz/f4/X5f4/8vu9MMMcO9dqWV/tjo68ny3S8KViV4x16d7pwI1aDEwMDAAACeykgIsu1eFAAAAAElFTkSuQmCC",
            blurWidth: 8,
            blurHeight: 8
        }, x = {
            src: "/_next/static/media/gold.4766b931.png",
            height: 70,
            width: 77,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA6klEQVR42j2PO0tCcRiH393GhoaGoiK7DC6BERE2hWs1RFNLH6A+RbT1AaqhLSMIWoo8BpGK99vRQRRB8bqo6NHzf9//Txz0WR944KEZUntxcfXnX0UvDdsg51wApoNL9w8qcQFVuIFtXmNsUE+agS/AuiLd/jiW6isk5YROHDKyXh4HXVCpW+jun5fsELk5TMzBNZ1/3EHxfRvDzw2M/DTAL22RMs8POHcCy7+Mkm9TKr4Vqb/tgjNnkMDqHkEap7ofa3GSZJrufK/DinuA8t1z/4kcBJVeAIaLEiEPZ/eL2nTnEF06mk1MACNsjRiia2wWAAAAAElFTkSuQmCC",
            blurWidth: 8,
            blurHeight: 7
        }, g = {
            src: "/_next/static/media/ruby.d47c8540.png",
            height: 73,
            width: 76,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/0lEQVR42mNomn6RiQEK/vz7H9E2+exOBoZV0lAhRgYYCM7YXzd1wbn/YY0H/8cXH3j08uX/qv///zMx1M14w3vl2udDmV3H/zuvvfe/+NLXXzlb7v/fc/zJ//oJFzsZkrovqjX3nf6fuPnh/xk3Pvzbvmfl/5aLH//Id1/8H1Ow9x4DCAg5rN/su+Le/41nr/zZMKHwf+Ghj39cey/8T8zb1cwAsmf7rsf7U2ef+5978c/P0OP//0Ye+Pa3aeHV/739l8wZ7j/4L/vsxZ9dmfVH/we1n/gfDzQpqOHI//LOU5cYkEFs9XGfpqYjSRV5m2IaWo6nmmQdMGBgYGAAACcCjWD9TEf9AAAAAElFTkSuQmCC",
            blurWidth: 8,
            blurHeight: 8
        }, b = a(71203), v = a(94224);
        function p(e) {
            let {userId: t, size: a="medium"} = e
              , {data: s} = (0,
            o.a)(t)
              , r = (0,
            b.d)(s)
              , p = (0,
            i.useMemo)(()=>r < 5 ? "wood" : r < 10 ? "bronze" : r < 30 ? "gold" : "ruby", [r])
              , {badge: w, border: j} = (0,
            i.useMemo)(()=>{
                switch (p) {
                case "wood":
                default:
                    return {
                        border: c,
                        badge: f
                    };
                case "bronze":
                    return {
                        border: A,
                        badge: m
                    };
                case "gold":
                    return {
                        border: h,
                        badge: x
                    };
                case "ruby":
                    return {
                        border: u,
                        badge: g
                    }
                }
            }
            , [p])
              , {sizeAvatar: N, sizeBorder: E, sizeMedal: Z} = (0,
            i.useMemo)(()=>{
                switch (a) {
                case "small":
                    return {
                        sizeBorder: "w-8 h-8",
                        sizeMedal: 12,
                        sizeAvatar: 28
                    };
                case "medium":
                    return {
                        sizeBorder: "w-12 h-12",
                        sizeMedal: 18,
                        sizeAvatar: 42
                    };
                case "large":
                    return {
                        sizeBorder: "w-16 h-16",
                        sizeMedal: 21,
                        sizeAvatar: 58
                    }
                }
            }
            , [a]);
            return (0,
            l.jsxs)("div", {
                className: (0,
                v.Z)("relative", E),
                children: [(0,
                l.jsx)(d.Z, {
                    userId: s._id,
                    size: N
                }), (0,
                l.jsx)("div", {
                    className: "absolute -top-[2.5px] -left-[2.5px]",
                    children: (0,
                    l.jsx)(n.default, {
                        src: j,
                        className: E,
                        alt: "border"
                    })
                }), (0,
                l.jsx)("div", {
                    className: "absolute bottom-0 right-[6px]",
                    children: (0,
                    l.jsx)(n.default, {
                        src: w,
                        width: Z,
                        alt: "badge"
                    })
                })]
            })
        }
        (s = r || (r = {})).Wood = "wood",
        s.Bronze = "bronze",
        s.Gold = "gold",
        s.Ruby = "ruby"
    },
    71203: function(e, t, a) {
        a.d(t, {
            d: function() {
                return l
            }
        });
        var s = a(13352);
        let r = Array.from({
            length: 51
        }, (e,t)=>.08 * Math.pow(t, 3))
          , l = e=>(0,
        s.useMemo)(()=>(function(e) {
            for (let t = 0; t < r.length; t++)
                if (e < r[t])
                    return t - 1;
            return 50
        }
        )(e.totalTokenEarned) + 1, [e.totalTokenEarned])
    },
    21440: function(e, t) {
        t.Z = {
            src: "/_next/static/media/guild-master.19b9e570.svg",
            height: 18,
            width: 22,
            blurWidth: 0,
            blurHeight: 0
        }
    },
    15574: function(e, t) {
        t.Z = {
            src: "/_next/static/media/guild.1cdbcdc9.png",
            height: 144,
            width: 145,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA9klEQVR42mO4sNKHkQEMHNi+3YvM/3uOoQTE6/n/n/F4KQMjw6P9DiwggQ8n7Xq/X/b8f31L7v9DfSXFDMjg3x1V4xObu/+/OuL3d/eGBf+3Tm7//2sag6ZObC4/Awh8PmJS/nhX+v8n2/1+PVxh/OvOXN3/T6YL1c+tMxZgCGEQFXh9xtbgyzmrfxen+Pw/2+7769kGnf+XpqgmMYDA4+miCv+nSuW8XmX18kKn//8rvcH/H/Tq//8xVWbdh+nqYQxXZwk5vpuqtOzbbL03nyYZ/HnbpvbubbvMum+zVJY/n6tYCnfovuu+Mvf3GJmeWMWgjOwBAOufc8RvtOq0AAAAAElFTkSuQmCC",
            blurWidth: 8,
            blurHeight: 8
        }
    },
    64545: function(e, t) {
        t.Z = {
            src: "/_next/static/media/funds.a273d2e3.png",
            height: 384,
            width: 385,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBElEQVR42mOYO3cd0/zuDmEGCGCB0szb1m6Q3rR6HSvDhIJ4bgaG/8ynZ1u43ljqsv7aEpfjW2oYzHbvP6Oyft40XoaSgGBeBgZRiSXFxkc3Z2v9nx+t+j/TRjebAQi6KmslwOZl2mimLS1ymrQm2+j/plz1X/Ojtf77mloagSVPHTygZM3A5rez0vD/lZn2/99sdvl1scv0/xRz3sx5Zy9zgxWtS9csP9Fh8X9akPLPC9Mtf19tM/6/2k/+CFjy5jQGrUMNht9PtVv8nxci//9wic7/HUB3rI5V/HBjum49w/05Bp2nOzTmrs1Q37MiWuXMAk+pq+uy5T9emax95fYUrSAATVtsfh/olbAAAAAASUVORK5CYII=",
            blurWidth: 8,
            blurHeight: 8
        }
    },
    11976: function(e, t) {
        t.Z = {
            src: "/_next/static/media/thief.c2f30622.svg",
            height: 63,
            width: 63,
            blurWidth: 0,
            blurHeight: 0
        }
    },
    94027: function(e, t) {
        t.Z = {
            src: "/_next/static/media/bee-coin.71d7f0e5.png",
            height: 71,
            width: 70,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBElEQVR42jXLPUsCAQAG4Lcgiv5Crc1BY7S2NeVgDa6BQdHiUJvIYbklRJhlUVhLHC0VFBdXeMfVSeVQFx4JUmSdcpBEfpx3r7f47A9I9sEXWxmZuZfip/mbqJiOjS8A6EePuDe7Zn9e0msY9Fom/yoilaNpGcAwQgOYrL5nSdqkpTisPXTYNNr/z6vMhpGEvIOkW9fpVTXHVjf4q2+y/ZPzXCNDLYIi1NToftNSWD+f7zwKoBQFTfXAP9u8CuIFu3MIlZUtWh95p/R05pqvt27tS2+9pQOMAOuAT0qMnZS1DCulHL+L1ywcLzE+hTtAGERPKojwhTAhHy6iEAASwPIQAHQBrSeTvNfWQUMAAAAASUVORK5CYII=",
            blurWidth: 8,
            blurHeight: 8
        }
    },
    96846: function(e, t, a) {
        var s = a(13352);
        let r = s.forwardRef(function(e, t) {
            let {title: a, titleId: r, ...l} = e;
            return s.createElement("svg", Object.assign({
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                strokeWidth: 1.5,
                stroke: "currentColor",
                "aria-hidden": "true",
                "data-slot": "icon",
                ref: t,
                "aria-labelledby": r
            }, l), a ? s.createElement("title", {
                id: r
            }, a) : null, s.createElement("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M3.75 4.875c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5A1.125 1.125 0 0 1 3.75 9.375v-4.5ZM3.75 14.625c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5a1.125 1.125 0 0 1-1.125-1.125v-4.5ZM13.5 4.875c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5A1.125 1.125 0 0 1 13.5 9.375v-4.5Z"
            }), s.createElement("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M6.75 6.75h.75v.75h-.75v-.75ZM6.75 16.5h.75v.75h-.75v-.75ZM16.5 6.75h.75v.75h-.75v-.75ZM13.5 13.5h.75v.75h-.75v-.75ZM13.5 19.5h.75v.75h-.75v-.75ZM19.5 13.5h.75v.75h-.75v-.75ZM19.5 19.5h.75v.75h-.75v-.75ZM16.5 16.5h.75v.75h-.75v-.75Z"
            }))
        });
        t.Z = r
    }
}]);
