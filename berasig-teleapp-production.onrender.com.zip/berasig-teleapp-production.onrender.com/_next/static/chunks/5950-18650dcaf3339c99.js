"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[5950], {
    33028: function(e, t, a) {
        a.d(t, {
            Z: function() {
                return g
            }
        });
        var A = a(45615);
        a(13352);
        var i = a(48278)
          , l = a(70978)
          , n = a(27904)
          , s = a(42784)
          , r = {
            src: "/_next/static/media/1st-badge.3343f4a7.svg",
            height: 25,
            width: 23,
            blurWidth: 0,
            blurHeight: 0
        }
          , o = {
            src: "/_next/static/media/crow.05c00862.svg",
            height: 17,
            width: 22,
            blurWidth: 0,
            blurHeight: 0
        }
          , c = a(56082);
        let d = {
            [n.t.DefaultFrame]: {
                frame: {
                    src: "/_next/static/media/defaultF.890cca7c.svg",
                    height: 64,
                    width: 64,
                    blurWidth: 0,
                    blurHeight: 0
                },
                badge: r
            },
            [n.t.OneST]: {
                frame: {
                    src: "/_next/static/media/1st-frame.33440065.svg",
                    height: 65,
                    width: 66,
                    blurWidth: 0,
                    blurHeight: 0
                },
                badge: r
            },
            [n.t.TwoND]: {
                frame: {
                    src: "/_next/static/media/2nd-frame.656ca1fc.svg",
                    height: 65,
                    width: 65,
                    blurWidth: 0,
                    blurHeight: 0
                },
                badge: {
                    src: "/_next/static/media/2nd-badge.a7f54991.svg",
                    height: 25,
                    width: 23,
                    blurWidth: 0,
                    blurHeight: 0
                }
            },
            [n.t.ThreeRD]: {
                frame: {
                    src: "/_next/static/media/3rd-frame.9007695b.svg",
                    height: 66,
                    width: 66,
                    blurWidth: 0,
                    blurHeight: 0
                },
                badge: {
                    src: "/_next/static/media/3rd-badge.6966edf2.svg",
                    height: 25,
                    width: 23,
                    blurWidth: 0,
                    blurHeight: 0
                }
            },
            [n.t.OtherTH]: {
                frame: {
                    src: "/_next/static/media/other-frame.2b9b170f.svg",
                    height: 65,
                    width: 65,
                    blurWidth: 0,
                    blurHeight: 0
                },
                badge: {
                    src: "/_next/static/media/other-badge.2ca54c82.svg",
                    height: 25,
                    width: 23,
                    blurWidth: 0,
                    blurHeight: 0
                }
            }
        }
          , u = {
            [n.G.One]: c.Z,
            [n.G.Two]: {
                src: "/_next/static/media/avt2.aa6578bd.png",
                height: 240,
                width: 241,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABC0lEQVR42mNAB/5TGMSWbWcI2XXYwgEs8P//TpZjhyNNpm1Idd15aUdU37re97PWNfxvmx7+oX15oTfD0g3O59tmh2yYuTZv3qFjs7/t31nzf/XGur9rNsXfmzxf+wPDolW9vzasrXixb3X8r4X1Hv8v7mj5e3x9+v+F08P/J5Qm/2c4tCn1w4VdSf9rk3j+H5hZ/e/4io7/xxbW/N80I/lvVoHVb4a2Ou1v2xZ5/X94vOHPpQ3Zf/bMC/mzabHv35kTLP7nFVj8Z1jdm18wr8n6w56Z4f+fby//v3my5//CDPn/RbkeH3qai3rBPllXWaKyJtbI/1izf0FPkGNueVhAbHdTjTwDAwMDAPbsiDTQpwJ0AAAAAElFTkSuQmCC",
                blurWidth: 8,
                blurHeight: 8
            },
            [n.G.Three]: {
                src: "/_next/static/media/avt3.4c4ce2cc.png",
                height: 240,
                width: 241,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AX6jWgCCqwMDqHYGU//9/zTk6/Y29vvzFd3i/sGid7dsAb7ZbADm6fZV29/tqtnZ7wDk4ewAIRoIAODyEAD9EB2vAWyYZhcC++XK+OoHAvrb9OsB9OEv9RozABQn/QLE1/L4AYObeQB9ZdELXXYSNezz/ItVHv8x9vP6AbjwCwIIFxqSAa6/dUe70BtJ6fgBJy8kCxLqtqcpGfz0DdkGFgAjOT2wAX2VZ4bv9gF5+QD8AAff2QDpv+D/Ij4X/QEN/wTzDQ7kAUhrSpQlDfdrJB4CABkHEADx6/gA4vX3APIBBAAC/QHqAWqBUSQYCfxeAwjvHCgdFgz19hcA0t3t4PEHAPMM7+PL8wR9YiB9aTkAAAAASUVORK5CYII=",
                blurWidth: 8,
                blurHeight: 8
            },
            [n.G.Four]: {
                src: "/_next/static/media/avt4.aa17db0c.png",
                height: 240,
                width: 241,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AZndnQBmIkcGAQEc+gAAAAEAdgD/tmRZk6y+6BSeaApoAbfnm2Xk59+DicPtY1kk8bUjFAlg/fzpn7fD4gC23DO4AYO9jf3y8Q4CAw8otwj1ykrp6HOZ6e0uZvD1DvnzCUwHAWacY+8tHDkQEQ4J4hIfKmzQ1dsv6+vdY/nzBhzd8+sDAX2ZUvPT78oM5vpeAEtcbAAX7M4A5t+t/A4MDgTt5fIAAXeecPA3HewP6fUo/L0AJv4OAg0DJu3iARgNy//l+tgBAW2GS/86LDoAFRXzAMvV4ADO6S4AIi08APP69wAh9eEAATVlJY4aFU03GAX6/kAv8ua83OUHRTNmBP4kJebc7gPHM1R7j/me+EAAAAAASUVORK5CYII=",
                blurWidth: 8,
                blurHeight: 8
            },
            [n.G.Five]: {
                src: "/_next/static/media/avt5.fa6dff41.png",
                height: 240,
                width: 241,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AWePkjftAuNxGR0XDh8ZJJLv6NS4aVB4CbvHxSvY2tsaAT1qX+EiCu4eAQ4RANj3AvlZS0GX4QERUfzi8A0YAQTqAX52S/lLLioGDg0Q/NLp1ATjEhgA4fwpAOPd6AAJ9gv8Aa6+pKIK/wFdDwD2/iE8NQHF4fP+9vkDAfDu9ALs5vrnAayxs9rn/f0lH//p/yY/SwHlBQUA79nNANv29gAp+Qb8AZWBhvf9+/UHFiHf/ycuNgHT7gb/y77MABUnL/8tEBgBAX+unfz08O8DLQTLABciOQDwHUEA89S/AAjr2wDX3PgAAYKpooPs6N847M3iIDc4Df4OFAf4/PLl6PsECv7p4A/oVrCAVLabd6UAAAAASUVORK5CYII=",
                blurWidth: 8,
                blurHeight: 8
            },
            [n.G.Six]: {
                src: "/_next/static/media/avt6.03322d2e.png",
                height: 240,
                width: 241,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/klEQVR42mNAB/2JOUwgunzuzjQG3+m8DFnlPQ4ggbyaSUw7Nu5gAbG37Dpl2zN38/+8yv7TDOEJhQtAgksmTmIF0f//v2LfvXjx/Z1LFvyvzyj5zxARnfJ2dkdPEsyKy0umVR+Z0vZ/76SmX0sbsv4yBEZE/uqpa/z/+OjBov/3DtpcnN/y/9yMsv8Xl5T9O7W87D9DSlLSu6KctP+9jUX/z6/r+PX2SM//yxsKfu9aVP9nelvSH4bGyrj/NTmh/9vznf7vnpTy/83Raf/3zsn4P6cn8/+kxsT/DPMmBaYubYwq2tGelPr10oqWN2dX1OyZ2ZCzcXF74cKpcZMAPYKA/bdpbsEAAAAASUVORK5CYII=",
                blurWidth: 8,
                blurHeight: 8
            },
            [n.G.Seven]: {
                src: "/_next/static/media/avt7.d3ba55a9.png",
                height: 240,
                width: 241,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AYWiuzM/JQ0huuH5Lbja7jInB/5MBAYGtBgQCcgUDQW6AXukvO8JEw0NEf36A+L0+gAyA/L+tOsDAi4fFQAqDQLPAbLf4fT+6+YL98fF/PYSHwIN5NUCqAIk/1hKMf71/f8DAd7e1PO7qLUMGygnALzc9gAUEg0Ax9ToABslHwBISzH+AZ6gqvMKGBcM7fP5AAcKEwADCQcA/P38AOfc4gAjDwYAAUV5nPE4LB4O5vbi/jokGgEpCQoBD+PWAO7g2/3k4eQAAYKNh/7n7uYBEg4PACcm8AAe+uX/7NX9AQQJGgDA5/YAAZyCVJbX4tsuBQAjEv4UGAI6Ke0n7v0C8fXn8bPp0+3v+F12PJI8X5YAAAAASUVORK5CYII=",
                blurWidth: 8,
                blurHeight: 8
            },
            [n.G.Eight]: {
                src: "/_next/static/media/avt8.d1d356e2.png",
                height: 240,
                width: 241,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AXSx2vUQBP/U1/gFZycSDdAoEgADDAgD/fDz9jMlEwR8AdLk7fXt7u0JwN/yxhsWFocSCQLI8f8FJgkAAaw2GgQaAZ6qoPP8AQsLDQkP6xAkMFSOxOfDSBsAkxgK9WwE/fr6AY6ZgvMJDBoMBRMqAAoVIZL3BA3Q3NjXnvrn2QDa3sj/AZGrlvMMDAAMAP4G/yMgJwHz+QgAxdLiAO7m4f8WCf0BAZmqoPHv8ugOCQry/SoeCv8FBBABw9XpAQMFCwAfFi0AAX2DSv4qIyYB//z1AP0EGAACCAsA7+rbAAYJCwDh5esAAXaIeKrw/BYKFAz+CxD50/0XA/gjEPb48+T3/fnxDBcAL5Bxdwiw49AAAAAASUVORK5CYII=",
                blurWidth: 8,
                blurHeight: 8
            },
            [n.G.Nine]: {
                src: "/_next/static/media/avt9.2f1843de.png",
                height: 240,
                width: 241,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABAUlEQVR42gVAu07CUBj+/tNTToFyswIGMJqYMLLows4D6KZvY+Lg+5j4CMYBBoIDXiIgQlKxVtNSe+8hNHLk1avlD+wgOVQIhTDNBGOsWVbJ6Tb0GxrO11GmqCSEhoVp8ux7jm6vj22UQgktyX/+xgEpjdLb0sLD8DG7PDBByZRks4elHxH/+hhTTjWghSTP+0esXOxgFf5C8SbI8Sp43ppBzy+QI5cq7Qu4moHN5whxbIGJZ/C0IFJS85BBPds83YPtHcuiXqKA1SVDFYp+2rrVVB0nrQrphqDIe2e+sybX89nLjBhvlY3ras0+sz3sZ5TQ8r+2uptuO2s3ngzawtwBtJVspfNuCzAAAAAASUVORK5CYII=",
                blurWidth: 8,
                blurHeight: 8
            }
        }
          , h = Array.from({
            length: 10
        }, (e,t)=>34.29355281207133 * Math.pow(t, 3));
        function g(e) {
            let {id: t, rank: a} = e
              , {data: r} = (0,
            l.Af)(t)
              , {totalToken: c} = r
              , g = function(e) {
                for (let t = 0; t < h.length; t++)
                    if (e < h[t])
                        return t - 1;
                return 9
            }(c) + 1;
            return g > n.G.Nine && (g = n.G.Nine),
            (0,
            A.jsxs)("div", {
                className: "relative p-1 w-16 min-w-16 h-16 pointer-events-none select-none",
                children: [a === n.t.OneST && (0,
                A.jsx)(i.default, {
                    className: "absolute -top-2 left-1/2 -translate-x-1/2 z-[5]",
                    src: o,
                    alt: "crow"
                }), (0,
                A.jsx)(s.Z, {
                    className: "w-14 h-14",
                    src: null == r ? void 0 : r.thumbnail,
                    fallbackSrc: u[g],
                    alt: "avatar",
                    size: 14
                }), (0,
                A.jsx)(i.default, {
                    className: "absolute top-0 left-0 w-full h-full z-[4]",
                    src: d[a >= n.t.OtherTH ? n.t.OtherTH : a].frame,
                    alt: "frame"
                }), 0 !== a && (0,
                A.jsx)("div", {
                    className: "absolute z-[5] right-0 bottom-0",
                    children: (0,
                    A.jsxs)("div", {
                        className: "relative flex w-6 h-6 items-center justify-center",
                        children: [(0,
                        A.jsx)("p", {
                            className: "relative font-black text-white text-shadow z-[1]",
                            children: g
                        }), (0,
                        A.jsx)(i.default, {
                            className: "absolute w-full h-full object-cover",
                            src: d[a > n.t.OtherTH ? n.t.OtherTH : a].badge,
                            alt: "frame"
                        })]
                    })
                })]
            })
        }
    },
    52225: function(e, t, a) {
        var A = a(45615)
          , i = a(94224);
        let l = {
            right: "translate-x-0",
            left: "translate-x-0",
            top: "translate-y-0",
            bottom: "translate-y-0"
        }
          , n = {
            right: "translate-x-full",
            left: "-translate-x-full",
            top: "-translate-y-full",
            bottom: "translate-y-full"
        }
          , s = {
            right: "inset-y-0 right-0",
            left: "inset-y-0 left-0",
            top: "inset-x-0 top-0",
            bottom: "inset-x-0 bottom-0"
        }
          , r = {
            right: "rounded-l-[20px]",
            left: "rounded-r-[20px]",
            top: "rounded-b-[20px]",
            bottom: "rounded-t-[20px]"
        };
        t.Z = e=>{
            let {open: t, onClose: a, placement: o="bottom", children: c} = e;
            return (0,
            A.jsxs)("div", {
                id: "dialog-".concat(o),
                className: "relative z-[1000]",
                "aria-labelledby": "slide-over",
                role: "dialog",
                "aria-modal": "true",
                onClick: a,
                children: [(0,
                A.jsx)("div", {
                    className: (0,
                    i.W)("fixed inset-0 bg-[#0006] bg-opacity-75 transition-all", {
                        "opacity-100 duration-500 ease-in-out visible": t
                    }, {
                        "opacity-0 duration-500 ease-in-out invisible": !t
                    })
                }), (0,
                A.jsx)("div", {
                    className: (0,
                    i.W)({
                        "fixed inset-0 overflow-hidden": t
                    }),
                    children: (0,
                    A.jsx)("div", {
                        className: "absolute inset-0 overflow-hidden",
                        children: (0,
                        A.jsx)("div", {
                            className: (0,
                            i.W)("pointer-events-none fixed max-w-full", s[o]),
                            children: (0,
                            A.jsx)("div", {
                                className: (0,
                                i.W)("pointer-events-auto relative w-full h-full transform transition ease-in-out duration-500", {
                                    [n[o]]: !t
                                }, {
                                    [l[o]]: t
                                }),
                                onClick: e=>{
                                    e.preventDefault(),
                                    e.stopPropagation()
                                }
                                ,
                                children: (0,
                                A.jsx)("div", {
                                    className: (0,
                                    i.W)("h-full bg-body p-4 overflow-y-scroll", r[o], {
                                        "shadow-[0_-15px_39px_0px_#C16240]": t
                                    }),
                                    children: t ? c : null
                                })
                            })
                        })
                    })
                })]
            })
        }
    },
    16526: function(e, t, a) {
        a.d(t, {
            Z: function() {
                return d
            }
        });
        var A = a(45615)
          , i = a(13352)
          , l = a(48278)
          , n = a(79620)
          , s = a(59116)
          , r = a(28870)
          , o = a(52225);
        let c = e=>{
            let {onDone: t=()=>{}
            , onFailed: a=()=>{}
            } = e
              , l = (0,
            i.useRef)(null)
              , n = (0,
            i.useRef)(null)
              , [s,r] = (0,
            i.useState)(0)
              , [o,c] = (0,
            i.useState)(0)
              , [d,u] = (0,
            i.useState)(0)
              , [h,g] = (0,
            i.useState)(!1)
              , f = (0,
            i.useMemo)(()=>Math.floor(100 * Math.random()), [])
              , b = (0,
            i.useCallback)(()=>{
                let e = l.current
                  , t = null == e ? void 0 : e.getContext("2d");
                if (!e || !t)
                    return;
                let a = e.width
                  , A = e.height
                  , i = a / 4
                  , n = a / 100
                  , o = f / 100 * (a - i);
                c(o),
                u(i),
                t.clearRect(0, 0, a, A),
                t.fillStyle = "#EFD8D0",
                t.fillRect(0, 0, a, A),
                t.fillStyle = "#C16240",
                t.fillRect(0, 0, s, A),
                h ? (r(e=>e - n),
                s <= 0 && g(!1)) : (r(e=>e + n),
                s >= a && g(!0)),
                t.fillStyle = "#F1A02590",
                t.fillRect(o, 0, i, A)
            }
            , [h, f, s])
              , m = (0,
            i.useCallback)(()=>n.current = requestAnimationFrame(b), [b])
              , v = (0,
            i.useCallback)(()=>n.current ? (cancelAnimationFrame(n.current),
            n.current = null,
            s >= o && s <= o + d) ? t(!0) : a() : m(), [o, d, t, a, s, m]);
            return (0,
            i.useEffect)(()=>{
                m()
            }
            , [m]),
            (0,
            A.jsxs)(i.Fragment, {
                children: [(0,
                A.jsx)("canvas", {
                    className: "w-full h-4 rounded-3xl",
                    ref: l
                }), (0,
                A.jsx)("button", {
                    className: "btn p-5 w-full",
                    onClick: v,
                    children: "Confirm"
                })]
            })
        }
        ;
        function d(e) {
            let {onOk: t, disabled: a, children: d} = e
              , [u,h] = (0,
            i.useState)(!1)
              , {message: g} = (0,
            s.p)()
              , f = (0,
            i.useCallback)(()=>{
                g({
                    msg: "Confirm successfully!",
                    type: "success"
                }),
                t(),
                h(!1)
            }
            , [g, t])
              , b = (0,
            i.useCallback)(()=>{
                g({
                    msg: "Confirm failed, try again!",
                    type: "error"
                }),
                h(!1)
            }
            , [g]);
            return (0,
            A.jsxs)("span", {
                onClick: a ? void 0 : ()=>h(!0),
                children: [d, (0,
                A.jsxs)(o.Z, {
                    open: u,
                    onClose: ()=>{}
                    ,
                    children: [(0,
                    A.jsx)(l.default, {
                        className: "absolute -top-8 left-1/3 w-1/3",
                        src: n.Z,
                        alt: "Confetti upgraded"
                    }), (0,
                    A.jsxs)("div", {
                        className: "flex flex-col gap-4 mt-6",
                        children: [(0,
                        A.jsx)("div", {
                            className: "flex flex-col gap-1 max-level-card p-4 items-center w-full text-white",
                            children: (0,
                            A.jsx)("div", {
                                className: "relative w-44 h-44",
                                children: (0,
                                A.jsx)(l.default, {
                                    src: r.Z,
                                    alt: "Bee",
                                    className: "object-contain"
                                })
                            })
                        }), (0,
                        A.jsx)(c, {
                            onDone: f,
                            onFailed: b
                        })]
                    })]
                })]
            })
        }
    },
    42796: function(e, t, a) {
        a.d(t, {
            Dd: function() {
                return s
            },
            Vb: function() {
                return i
            },
            bl: function() {
                return l
            },
            hn: function() {
                return r
            },
            mI: function() {
                return A
            },
            we: function() {
                return n
            }
        });
        let A = ()=>{
            "false" !== localStorage.getItem("soundEffects")
        }
          , i = ()=>{
            "false" !== localStorage.getItem("soundEffects")
        }
          , l = ()=>{
            "false" !== localStorage.getItem("soundEffects")
        }
          , n = ()=>{
            "false" !== localStorage.getItem("soundEffects")
        }
          , s = ()=>{
            "false" !== localStorage.getItem("soundEffects")
        }
          , r = ()=>{
            "false" !== localStorage.getItem("soundEffects")
        }
    },
    25661: function(e, t, a) {
        let A;
        a.d(t, {
            Q: function() {
                return o
            }
        });
        var i = a(13352)
          , l = a(6059)
          , n = a(946)
          , s = a.n(n)
          , r = a(91225);
        let o = e=>{
            var t, a;
            let n = (0,
            l.a)(e)
              , {data: o} = (0,
            r._)(n.data._id)
              , [c,d] = (0,
            i.useState)(0)
              , u = (0,
            i.useMemo)(()=>{
                var e, t;
                let a = (null === (t = n.data) || void 0 === t ? void 0 : null === (e = t.stolenBy) || void 0 === e ? void 0 : e.length) || 0;
                return a && o.size && c ? o.size * a * .05 : 0
            }
            , [c, null === (a = n.data) || void 0 === a ? void 0 : null === (t = a.stolenBy) || void 0 === t ? void 0 : t.length, o.size]);
            return (0,
            i.useEffect)(()=>(A && clearInterval(A),
            A = setInterval(()=>{
                let e = (s()().valueOf() - s()(n.data.lastClaimAt).valueOf()) / 1e3 / 60 / 60 * o.speed;
                e > o.size && (e = o.size),
                d(e),
                e >= o.size && clearInterval(A)
            }
            , 1e3),
            ()=>clearInterval(A)), [n.data.lastClaimAt, o.size, o.speed]),
            (0,
            i.useMemo)(()=>({
                data: {
                    amount: c,
                    maximum: o.size,
                    totalStolen: u
                },
                loading: n.loading
            }), [c, u, n.loading, o.size])
        }
    },
    75380: function(e, t, a) {
        a.d(t, {
            default: function() {
                return b
            },
            c: function() {
                return f
            }
        });
        var A = a(45615)
          , i = a(13352)
          , l = a(25652)
          , n = a(82216)
          , s = a(48278)
          , r = a(52225)
          , o = a(33078);
        function c(e) {
            let {setValue: t, contentClassName: a, className: l} = e
              , n = (0,
            i.useRef)(null)
              , s = (0,
            i.useCallback)(e=>{
                let t = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                  , a = "";
                for (let A = 0; A < e; A++) {
                    let e = Math.floor(Math.random() * t.length);
                    a += t[e]
                }
                return a
            }
            , [])
              , r = (0,
            i.useCallback)(e=>{
                let t = n.current;
                if (!t)
                    return;
                let a = t.getContext("2d");
                a && (a.clearRect(0, 0, t.width, t.height),
                a.fillStyle = "transparent",
                a.fillRect(0, 0, t.width, t.height),
                a.font = "24px Arial",
                a.fillStyle = "#000000",
                a.textAlign = "center",
                a.textBaseline = "middle",
                a.fillText(e, t.width / 2, t.height / 2),
                a.strokeStyle = "#000",
                a.lineWidth = 1,
                a.beginPath(),
                a.moveTo(0, 0),
                a.lineTo(t.width, t.height),
                a.stroke(),
                a.fillStyle = "#000",
                a.fillRect(0, t.height / 2, t.width, 1.5),
                a.strokeStyle = "#000",
                a.lineWidth = 1,
                a.beginPath(),
                a.moveTo(0, t.height),
                a.lineTo(t.width, 0),
                a.stroke())
            }
            , [])
              , c = (0,
            i.useCallback)(()=>{
                let e = s(3);
                t(e),
                r(e)
            }
            , [r, s, t]);
            return (0,
            i.useEffect)(()=>{
                c()
            }
            , [c]),
            (0,
            A.jsxs)("div", {
                className: "w-full flex flex-row gap-2 p-1 pr-4 justify-between border border-border bg-[#FFF2EA] rounded-2xl ".concat(l),
                children: [(0,
                A.jsx)("div", {
                    className: a,
                    children: (0,
                    A.jsx)("canvas", {
                        ref: n,
                        height: 36,
                        width: 120
                    })
                }), (0,
                A.jsx)(o.Z, {
                    className: "cursor-pointer w-5",
                    onClick: c
                })]
            })
        }
        var d = a(6059)
          , u = {
            src: "/_next/static/media/warning.19966d29.png",
            height: 360,
            width: 686,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAbElEQVR42mNI89GaHW0W7KpT76/bEGAYbKOd5qAXZ6XHwMOqHyuqn2RkcLDGfl+FnaOMJgOnLoOIPoO2sRODiXWGc3J/buSkrJBMjyh7SQUGXj2GnHDzgmjbRF+3gqjUrKCwZHfbZFuNWAtNADNuGtUlNHTmAAAAAElFTkSuQmCC",
            blurWidth: 8,
            blurHeight: 4
        }
          , h = a(32530)
          , g = a(4049);
        let f = (0,
        l.Ue)()((0,
        n.tJ)(e=>({
            checkBot: 0,
            checkedPoint: 0,
            setCheckBot: ()=>e((0,
            g.Uy)(e=>{
                e.checkBot = e.checkBot + 1
            }
            )),
            setCheckedPoint: t=>e((0,
            g.Uy)(e=>{
                e.checkedPoint = t,
                e.checkBot = 0
            }
            ))
        }), {
            name: "warning::agreed",
            storage: (0,
            n.FL)(()=>localStorage)
        }));
        function b(e) {
            let {children: t} = e
              , {data: a} = (0,
            d.a)()
              , [l,n] = (0,
            i.useState)("")
              , [o,g] = (0,
            i.useState)("")
              , [b,m] = (0,
            i.useState)(!1)
              , {checkBot: v, checkedPoint: p, setCheckedPoint: x} = f()
              , w = (0,
            i.useMemo)(()=>{
                let e = 0;
                if (a.botApiCount && (e += a.botApiCount),
                a.toolLogs)
                    for (let t of a.toolLogs)
                        e += t.count;
                return e
            }
            , [a.botApiCount, a.toolLogs])
              , D = (0,
            i.useMemo)(()=>{
                let e = 0;
                if (a.hisBotApiCount && (e += a.hisBotApiCount),
                a.hisToolLogs)
                    for (let t of a.hisToolLogs)
                        e += t.count;
                return e
            }
            , [a.hisBotApiCount, a.hisToolLogs])
              , C = 100;
            w > 100 && (C = 50),
            w > 500 && (C = 10),
            (0,
            i.useEffect)(()=>{
                let e = w + D > 20 && p < v - C
                  , t = p < v - 280;
                (e || t) && m(!0)
            }
            , [C, w, v, p, D]);
            let E = (0,
            i.useCallback)(()=>{
                if (o) {
                    m(!1),
                    x(w)
                }
            }
            , [w, l, x, o]);
            (0,
            i.useEffect)(()=>{
                let e;
                return b && (e = setInterval(()=>{
                    (0,
                    h.M)("Bot Detected - Account at Risk (".concat(l, ")"))
                }
                , 15e3)),
                ()=>{
                    e && clearTimeout(e)
                }
            }
            , [l, b]);
            let B = w > 30 ? "Cheating Detected - Account at Risk" : "DatHacky \n"
              , N = w > 30 ? " We suspect your account of cheating. Close the unauthorized app\n                and play fairly immediately to avoid a ban" : "We noticed some activity that might indicate automated use. To keep our platform secure, please verify you're a human by completing this quick step to avoid a ban.";
            return (0,
            A.jsxs)(i.Fragment, {
                children: [t, (0,
                A.jsx)(r.Z, {
                    open: b,
                    onClose: ()=>{}
                    ,
                    children: (0,
                    A.jsxs)("div", {
                        className: "flex flex-col gap-4 hidden",
                        children: [(0,
                        A.jsxs)("div", {
                            className: "hidden card flex-col gap-4 !p-0 overflow-hidden",
                            children: [(0,
                            A.jsx)(s.default, {
                                src: u,
                                alt: "warning"
                            }), (0,
                            A.jsxs)("div", {
                                className: "hidden flex flex-col gap-2 p-4",
                                children: [(0,
                                A.jsxs)("p", {
                                    className: " hidden text-base text-danger font-bold text-center",
                                    children: [B, " (", w, ")"]
                                }), (0,
                                A.jsx)("span", {
                                    className: "hidden text-center",
                                    children: N
                                }), (0,
                                A.jsx)(c, {
                                    className: "py-2",
                                    contentClassName: "hidden w-full flex justify-center",
                                    setValue: n
                                }), (0,
                                A.jsx)("input", {
                                    placeholder: "by pass captcha",
                                    className: "input input-lg border-border rounded-2xl text-center hidden",
                                    value: o,
                                    onChange: e=>g(e.target.value),
                                    style: {
                                        outline: "none"
                                    }
                                })]
                            })]
                        }), (0,
                        A.jsx)("button", {
                            className: "btn p-4",
                            onClick: E(),
                            disabled: !o,
                            children: ":D"
                        })]
                    })
                })]
            })
        }
    },
    28870: function(e, t) {
        t.Z = {
            src: "/_next/static/media/catch.580da03d.svg",
            height: 343,
            width: 343,
            blurWidth: 0,
            blurHeight: 0
        }
    },
    56082: function(e, t) {
        t.Z = {
            src: "/_next/static/media/avt1.d023b835.png",
            height: 240,
            width: 241,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBklEQVR42mM4d9uZhQEIVuy3mjNvm9l/zir/mLolUVZAITYGGJCvtHXMm6H+v2OVxn+lTL3f9lWRv6oXZISeuhvFz/D/fzl37QKHA5YJ2v9tnYR/ZSY6/e8t8v+/5bj3//aVHq8ZZu8wK2+d7/JXz8X5U6uX5Z/jK9r+39zf9m/iJqH/0T0m/xl2NCQbzKmNuNudZfZ/boXBvxWu2v/31ob8KwrT+u+U6PyUYUWN54t9vc7/v62L+vtpTezfN9P9/i2vlv+7pSHkf1Wu3X+G+iQGk0NTrRZeWer+/8ISr/9Xprv+X9+h/39Og8HJUg/eCAYYKMlgMFnYrXC4OVv8ZrguQyhMHABmCXc0rpH3rgAAAABJRU5ErkJggg==",
            blurWidth: 8,
            blurHeight: 8
        }
    },
    79620: function(e, t) {
        t.Z = {
            src: "/_next/static/media/star-confetti.c76d87cc.png",
            height: 148,
            width: 345,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR4nAFjAJz/Af//rgUAAP8M7ZVTAhNKcnoABwcA77GHhxFdn/8ADBXzAfzOW5oCBf9i89DQZQkgE5j//gQG+OPlYg0uMZv+AAmhAfevG2P17+9i790WaAoD4CHr4AAGHTYI1v4JBZYEBhKrV+wqo4NibaEAAAAASUVORK5CYII=",
            blurWidth: 8,
            blurHeight: 3
        }
    },
    94027: function(e, t) {
        t.Z = {
            src: "/_next/static/media/bee-coin.71d7f0e5.png",
            height: 71,
            width: 70,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBElEQVR42jXLPUsCAQAG4Lcgiv5Crc1BY7S2NeVgDa6BQdHiUJvIYbklRJhlUVhLHC0VFBdXeMfVSeVQFx4JUmSdcpBEfpx3r7f47A9I9sEXWxmZuZfip/mbqJiOjS8A6EePuDe7Zn9e0msY9Fom/yoilaNpGcAwQgOYrL5nSdqkpTisPXTYNNr/z6vMhpGEvIOkW9fpVTXHVjf4q2+y/ZPzXCNDLYIi1NToftNSWD+f7zwKoBQFTfXAP9u8CuIFu3MIlZUtWh95p/R05pqvt27tS2+9pQOMAOuAT0qMnZS1DCulHL+L1ywcLzE+hTtAGERPKojwhTAhHy6iEAASwPIQAHQBrSeTvNfWQUMAAAAASUVORK5CYII=",
            blurWidth: 8,
            blurHeight: 8
        }
    }
}]);
