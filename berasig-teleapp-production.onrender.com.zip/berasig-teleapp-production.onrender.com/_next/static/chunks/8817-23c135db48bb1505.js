(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[8817], {
    79391: function() {},
    66442: function(e, t, a) {
        "use strict";
        a.d(t, {
            QV: function() {
                return d
            },
            cD: function() {
                return m
            },
            v0: function() {
                return o
            }
        });
        var r = a(60397)
          , n = a(4159)
          , s = a(29117)
          , l = a(92517)
          , i = a(19814)
          , c = a(85182)
          , u = a(82261);
        let o = ()=>{
            let e = localStorage.getItem("AUTH:USER_ID")
              , t = localStorage.getItem("AUTH:SERVER_ID");
            return {
                userId: e,
                serverId: t,
                bccToken: localStorage.getItem("AUTH:TOKEN"),
                lifeTime: localStorage.getItem("AUTH:LIFE_TIME"),
                teleAuth: localStorage.getItem("AUTH:TELE_AUTH")
            }
        }
          , d = e=>{
            e.userId && localStorage.setItem("AUTH:USER_ID", e.userId),
            e.serverId && localStorage.setItem("AUTH:SERVER_ID", e.serverId),
            e.bccToken && localStorage.setItem("AUTH:TOKEN", e.bccToken),
            e.lifeTime && localStorage.setItem("AUTH:LIFE_TIME", e.lifeTime),
            e.teleAuth && localStorage.setItem("AUTH:TELE_AUTH", e.teleAuth)
        }
          , f = r.Z.create({
            baseURL: "".concat(l.default.cluster.beraSigServer, "/mining-app")
        })
          , m = async e=>{
            let t = await localStorage.getItem("user");
            if (!t)
                throw Error("User not found!");
            let a = JSON.parse(t).state.user
              , r = await s.getItem("ZUSTAND_KEYS");
            if (!r)
                throw Error("Please connect wallet first!");
            let l = JSON.parse(r).state.privateKey
              , o = JSON.stringify({
                signer: a.address,
                verifier: "BERA::BEE::CATCHER::VERIFIER",
                nonce: a.nonce,
                data: e
            })
              , d = (0,
            i.J)((0,
            c.Y0)(o))
              , f = (await (0,
            n.BL)((0,
            u.Pw)(d), l.privateKey)).toCompactHex()
              , m = "".concat(a.address, "/").concat(f, "/").concat(a.nonce);
            return {
                authorization: "Bearer ".concat(m)
            }
        }
        ;
        f.interceptors.request.use(e=>{
            let t = o();
            return e.headers.userId = null == t ? void 0 : t.userId,
            e.headers.serverId = null == t ? void 0 : t.serverId,
            e.headers.bccToken = null == t ? void 0 : t.bccToken,
            e.headers.bccLifetime = null == t ? void 0 : t.lifeTime,
            e.headers.bbcsalt = "berachain",
            e.headers.teleauth = t.teleAuth,
            e
        }
        , e=>Promise.reject(e)),
        t.ZP = f
    },
    1049: function(e, t, a) {
        "use strict";
        a.d(t, {
            Ah: function() {
                return u
            },
            ED: function() {
                return l
            },
            L3: function() {
                return w
            },
            Ol: function() {
                return c
            },
            QN: function() {
                return i
            },
            Sk: function() {
                return h
            },
            WX: function() {
                return s
            },
            Zl: function() {
                return v
            },
            _6: function() {
                return f
            },
            dO: function() {
                return o
            },
            eF: function() {
                return x
            },
            n6: function() {
                return m
            },
            tH: function() {
                return n
            },
            tp: function() {
                return d
            },
            yL: function() {
                return g
            },
            yr: function() {
                return p
            }
        });
        var r = a(66442);
        let n = async e=>{
            let {data: t} = await r.ZP.post("/guilds/create-guild", e);
            return t
        }
          , s = async e=>{
            let {data: t} = await r.ZP.post("/guilds/create-guild-request", {
                guildId: e
            });
            return t
        }
          , l = async e=>{
            let {data: t} = await r.ZP.patch("/guilds/accept-guild-request", {
                userId: e
            });
            return t
        }
          , i = async e=>{
            let {data: t} = await r.ZP.patch("/guilds/reject-guild-request", {
                userId: e
            });
            return t
        }
          , c = async e=>{
            let {data: t} = await r.ZP.patch("/guilds/leave-guild", {
                guildId: e
            });
            return t
        }
          , u = async e=>{
            let {data: t} = await r.ZP.patch("/guilds/remove-member", {
                userId: e
            });
            return t
        }
          , o = async e=>{
            let {data: t} = await r.ZP.patch("/guilds/transfer-owner", {
                userId: e
            });
            return t
        }
          , d = async e=>{
            let {data: t} = await r.ZP.patch("/guilds/appoint-deputy", {
                userId: e
            });
            return t
        }
          , f = async e=>{
            let {data: t} = await r.ZP.patch("/guilds/revoke-deputy", {
                userId: e
            });
            return t
        }
          , m = async e=>{
            let {data: t} = await r.ZP.get("/guilds", {
                params: e
            });
            return t
        }
          , g = async e=>{
            let {data: t} = await r.ZP.get("/guilds/group-info?link=".concat(e));
            return t
        }
          , h = async e=>{
            let {data: t} = await r.ZP.get("/guilds/".concat(e));
            return t
        }
          , p = async e=>{
            let {data: t} = await r.ZP.get("/guilds/skill-cheques", {
                params: {
                    guild: e
                }
            });
            return t
        }
          , x = async e=>{
            let {data: t} = await r.ZP.get("/guilds/skill-cheque/".concat(e));
            return t
        }
          , v = async(e,t)=>{
            let {data: a} = await r.ZP.patch("/guilds/upgrade-skill", {
                skillChequeId: e,
                amount: t
            });
            return a
        }
          , w = async e=>{
            let {data: t} = await r.ZP.patch("/guilds/update-guild", e);
            return t
        }
    },
    27904: function(e, t, a) {
        "use strict";
        var r, n, s, l;
        a.d(t, {
            G: function() {
                return n
            },
            t: function() {
                return r
            }
        }),
        (s = r || (r = {}))[s.DefaultFrame = 0] = "DefaultFrame",
        s[s.OneST = 1] = "OneST",
        s[s.TwoND = 2] = "TwoND",
        s[s.ThreeRD = 3] = "ThreeRD",
        s[s.OtherTH = 4] = "OtherTH",
        (l = n || (n = {}))[l.One = 1] = "One",
        l[l.Two = 2] = "Two",
        l[l.Three = 3] = "Three",
        l[l.Four = 4] = "Four",
        l[l.Five = 5] = "Five",
        l[l.Six = 6] = "Six",
        l[l.Seven = 7] = "Seven",
        l[l.Eight = 8] = "Eight",
        l[l.Nine = 9] = "Nine"
    },
    90047: function(e, t, a) {
        "use strict";
        a.d(t, {
            m: function() {
                return s
            },
            t: function() {
                return n
            }
        });
        var r = a(66442);
        let n = async e=>{
            let {data: t} = await r.ZP.get("/servers/".concat(e));
            return t
        }
          , s = async e=>{
            let {data: t} = await r.ZP.get("/servers/".concat(e, "/stat"));
            return t
        }
    },
    50087: function(e, t, a) {
        "use strict";
        var r, n;
        a.d(t, {
            D: function() {
                return r
            }
        }),
        (n = r || (r = {})).Member = "SKILL::MEMBER",
        n.Lucky = "SKILL::LUCKY",
        n.Size = "SKILL::SIZE",
        n.Speed = "SKILL::SPEED"
    },
    32530: function(e, t, a) {
        "use strict";
        a.d(t, {
            GJ: function() {
                return p
            },
            M: function() {
                return h
            },
            PR: function() {
                return s
            },
            Rf: function() {
                return i
            },
            Tj: function() {
                return f
            },
            Wt: function() {
                return g
            },
            d0: function() {
                return l
            },
            iX: function() {
                return d
            },
            jd: function() {
                return c
            },
            nX: function() {
                return o
            },
            pe: function() {
                return m
            },
            r4: function() {
                return n
            },
            y8: function() {
                return u
            }
        });
        var r = a(66442);
        let n = async e=>{
            let {data: t} = await r.ZP.post("/users", {
                ...e
            });
            return t
        }
          , s = async e=>{
            let {data: t} = await r.ZP.get("/users/".concat(e));
            return t
        }
          , l = async(e,t)=>{
            let {data: a} = await r.ZP.get("/users/by-telegram-id?server=".concat(e, "&telegramId=").concat(t));
            return a
        }
          , i = async e=>{
            let {data: t} = await r.ZP.get("/users", {
                params: e
            });
            return t
        }
          , c = async e=>{
            let {authorization: t} = await (0,
            r.cD)({
                txHash: e
            })
              , {data: a} = await r.ZP.patch("/users/claim-token", {
                txHash: e
            }, {
                headers: {
                    authorization: t
                }
            });
            return a
        }
          , u = async e=>{
            let t = (e.page - 1) * e.perPage
              , {data: a} = await r.ZP.get("/users/leaderboard", {
                params: {
                    offset: t,
                    limit: e.perPage,
                    ...e
                }
            });
            return a
        }
          , o = async e=>{
            let {userId: t} = e
              , {authorization: a} = await (0,
            r.cD)({
                userId: t
            })
              , {data: n} = await r.ZP.patch("/users/steal-token", {
                userId: t
            }, {
                headers: {
                    authorization: a
                }
            });
            return n
        }
          , d = async e=>{
            let {data: t} = await r.ZP.patch("/users/upgrade-item", e);
            return t
        }
          , f = async e=>{
            let {authorization: t} = await (0,
            r.cD)(e)
              , {data: a} = await r.ZP.patch("/users/quest/claim", e, {
                headers: {
                    authorization: t
                }
            });
            return {
                user: a.user,
                cert: a.cert
            }
        }
          , m = async e=>{
            let {authorization: t} = await (0,
            r.cD)(e)
              , {data: a} = await r.ZP.patch("/users/take-token", e, {
                headers: {
                    authorization: t
                }
            });
            return a
        }
          , g = async e=>{
            let {data: t} = await r.ZP.patch("/users/change-wallet", e);
            return t
        }
          , h = async e=>{
            return Promise.resolve()
        }
          , p = async e=>{
            let {data: t} = await r.ZP.get("/users/quest-certificates", {
                params: {
                    platform: e
                }
            });
            return t
        }
    },
    60346: function(e, t, a) {
        "use strict";
        a.r(t),
        a.d(t, {
            default: function() {
                return S
            }
        });
        var r = a(45615)
          , n = a(13352)
          , s = a(1385)
          , l = a(48278)
          , i = a(72278)
          , c = a(13317)
          , u = a(32530)
          , o = a(50529)
          , d = a(6059);
        let f = ()=>{
            let {createPrivateKey: e} = (0,
            i.$$)()
              , t = (0,
            d.L)(e=>e.setUser)
              , {name: a, username: r, referrer: s, id: l, thumbnail: f, isPremium: m, initData: g} = (0,
            c.wA)()
              , h = (0,
            o.Y)();
            return {
                onCreateUser: (0,
                n.useCallback)(async()=>{
                    let {publicKey: n} = await e()
                      , i = await (0,
                    u.r4)({
                        telegramId: l,
                        pubkey: n,
                        username: r,
                        name: a,
                        referrerId: s,
                        serverId: h.serverId,
                        isPremium: m,
                        thumbnail: f,
                        initData: g
                    });
                    return t(i),
                    i
                }
                , [h.serverId, e, l, g, m, a, s, t, f, r])
            }
        }
        ;
        var m = a(92725)
          , g = a(53045)
          , h = a(67338)
          , p = a(56471)
          , x = a(91225);
        function v(e) {
            let {data: t, loading: a} = (0,
            d.a)(e.referrer)
              , n = (0,
            x._)(e.referrer);
            return a ? (0,
            r.jsx)(h.Z, {
                msg: "Loading user"
            }) : (0,
            r.jsxs)("div", {
                className: "flex flex-col gap-2",
                children: [(0,
                r.jsx)(l.default, {
                    src: p.Z,
                    alt: "banner"
                }), (0,
                r.jsx)("div", {
                    className: "card !border-danger",
                    children: (0,
                    r.jsx)("span", {
                        className: "text-danger",
                        children: "This referral link is full! Try using a different one to join"
                    })
                }), (0,
                r.jsxs)("div", {
                    className: "card flex-col gap-1 items-center mb-2",
                    children: [(0,
                    r.jsxs)("p", {
                        className: "font-bold text-[18px] mb-4",
                        children: ["Henlo henlo ", (0,
                        r.jsx)("span", {
                            className: "text-danger text-[18px]",
                            children: "Beras"
                        })]
                    }), (0,
                    r.jsxs)("div", {
                        className: "w-full flex flex-row gap-4 justify-between items-center",
                        children: [(0,
                        r.jsx)("span", {
                            className: "text-secondary",
                            children: "Invited by:"
                        }), t && (0,
                        r.jsxs)("div", {
                            className: "flex flex-row gap-1 items-center",
                            children: [(0,
                            r.jsx)(m.Z, {
                                userId: t._id
                            }), (0,
                            r.jsx)("p", {
                                className: "font-bold",
                                children: t.name
                            }), (0,
                            r.jsxs)("span", {
                                className: "text-secondary",
                                children: ["(Lv ", 1, ")"]
                            })]
                        })]
                    }), (0,
                    r.jsxs)("div", {
                        className: "w-full flex flex-row gap-4 justify-between items-center",
                        children: [(0,
                        r.jsx)("span", {
                            className: "text-secondary",
                            children: "Referral limit reached:"
                        }), (0,
                        r.jsxs)("div", {
                            className: "flex flex-row gap-1 items-center",
                            children: [(0,
                            r.jsx)(g.Z, {
                                width: 18
                            }), (0,
                            r.jsxs)("p", {
                                className: "font-bold text-danger",
                                children: [n.data.ref, "/", t.totalReferral]
                            })]
                        })]
                    })]
                })]
            })
        }
        var w = a(15019)
          , y = {
            src: "/_next/static/media/bear-tele.8774c449.png",
            height: 1029,
            width: 1030,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABCUlEQVR42gVAz0rCYAD/fZ/bMmY0ZDUaDvtDRYdAOikEnbp26QXqVK8RHXqLrkHH6AkKIiNszFLCCQW6T90fs2G2yfYJVg/ATs8OecO8T6dhncfBCzfvLtPjI/D9k9KAvD7fcl1VIPz1kBIJ/kcdU+caiVyG1cmBlnY2k9hrISI6RNgYB4/w7C2oCzEqGuVC4PUJTSOwrxoU0YSsVfBLDQTjd6yXdULnxHkwZ4KNZQdSAoT9NlaWRsimDdhvTdDvbpNbnQeEvofWUxVKPkVb3oNq6DAWBzyT3+5d7BY4pGCEeFiAolIUpU8wNkS1+0MyNJs5dyPkhKLBI22N/LsexAnjNzWfXFnMnQGElnd86fdCHgAAAABJRU5ErkJggg==",
            blurWidth: 8,
            blurHeight: 8
        };
        a(91170),
        a(72363);
        let b = [{
            bg: y,
            title: "Your Gateway to Infinite",
            subTitle: "Bera Adventures",
            description: "Only those who follow the bee's path can enter. \n    <strong>Find a member with an invitation link</strong> to join the swarm."
        }];
        var A = ()=>(0,
        r.jsxs)("div", {
            className: "flex flex-col gap-4 text-center",
            children: [(0,
            r.jsx)("div", {
                className: "flex flex-col gap-4 text-center p-0",
                children: b.map(e=>(0,
                r.jsxs)("div", {
                    className: "flex flex-col gap-4 text-center",
                    children: [(0,
                    r.jsx)(l.default, {
                        src: e.bg,
                        alt: "welcome"
                    }), (0,
                    r.jsx)("h4", {
                        children: e.title
                    }), (0,
                    r.jsx)("h3", {
                        className: "text-[#F47226] font-bold",
                        children: e.subTitle
                    }), (0,
                    r.jsx)("p", {
                        dangerouslySetInnerHTML: {
                            __html: e.description
                        }
                    })]
                }, e.title))
            }), (0,
            r.jsx)("button", {
                className: "btn p-5 mt-4",
                onClick: ()=>window.open("https://t.me/BeraBeeCatcher", "_blank"),
                children: (0,
                r.jsx)("h5", {
                    className: "font-bold",
                    children: "Go to community"
                })
            })]
        })
          , j = a(59116);
        let N = [{
            bg: p.Z,
            title: "Your Gateway to Infinite",
            subTitle: "Bera Bee Catcher",
            description: "For more info on your wallet and to retrieve your private key, go\n      to Settings.\n      </br>We guarantee the safety of user funds on BeraSig Wallet,\n      <strong>\n        but if you expose your private key, your funds will not be safe.\n      </strong>"
        }, {
            bg: y,
            title: "YOU SHALL NOT PASS!",
            subTitle: "(Unless you have your seed phrase, that's it.)",
            description: "Don't let your crypto dreams turn into a meme because you forgot the key! Write it down, memorize it, tattoo it on your forehead (not recommended) - just keep it safe!"
        }];
        var S = ()=>{
            var e;
            let[t,a] = (0,
            n.useState)(!1)
              , {onCreateUser: i} = f()
              , {setUser: u} = (0,
            d.a)()
              , {referrer: o} = (0,
            c.wA)()
              , m = (0,
            d.a)(o)
              , g = (0,
            x._)(o)
              , {message: p} = (0,
            j.p)()
              , y = (0,
            n.useCallback)(async()=>{
                try {
                    a(!0);
                    let e = await i();
                    p({
                        msg: "Create wallet successfully",
                        type: "success"
                    }),
                    u(e)
                } catch (e) {
                    p({
                        msg: e.response.data.message,
                        type: "error"
                    })
                } finally {
                    a(!1)
                }
            }
            , [p, i, u]);
            return m.loading || g.loading ? (0,
            r.jsx)(h.Z, {
                msg: "Loading user onboarding"
            }) : o ? m.loading || (null === (e = m.data) || void 0 === e ? void 0 : e._id) ? m.data.totalReferral >= g.data.ref ? (0,
            r.jsx)(v, {
                referrer: o
            }) : (0,
            r.jsxs)("div", {
                className: "flex flex-col gap-4 text-center",
                children: [(0,
                r.jsx)("div", {
                    className: "flex flex-col gap-4 text-center p-0",
                    children: (0,
                    r.jsx)(s.lr, {
                        className: "swiper",
                        showThumbs: !1,
                        showArrows: !1,
                        showStatus: !1,
                        stopOnHover: !0,
                        children: N.map(e=>(0,
                        r.jsxs)("div", {
                            className: "flex flex-col gap-4 text-center",
                            children: [(0,
                            r.jsx)(l.default, {
                                src: e.bg,
                                alt: "welcome"
                            }), (0,
                            r.jsx)("h4", {
                                children: e.title
                            }), (0,
                            r.jsx)("h3", {
                                className: "text-[#F47226] font-bold",
                                children: e.subTitle
                            }), (0,
                            r.jsx)("p", {
                                dangerouslySetInnerHTML: {
                                    __html: e.description
                                }
                            }), (0,
                            r.jsxs)("span", {
                                className: "text-sm",
                                children: ["Invited by: ", (0,
                                r.jsx)("b", {
                                    children: m.data.name
                                })]
                            }), (0,
                            r.jsx)("div", {
                                className: "h-6"
                            })]
                        }, e.title))
                    })
                }), (0,
                r.jsxs)("button", {
                    className: "btn p-5",
                    onClick: y,
                    children: [(0,
                    r.jsx)("h5", {
                        className: "font-bold",
                        children: "Create new wallet"
                    }), t && (0,
                    r.jsx)("div", {
                        className: "loading"
                    })]
                })]
            }) : (0,
            r.jsx)(w.Z, {
                msg: "Referrer not found"
            }) : (0,
            r.jsx)(A, {})
        }
    },
    95471: function(e, t, a) {
        "use strict";
        a.r(t),
        a.d(t, {
            default: function() {
                return b
            }
        });
        var r = a(45615)
          , n = a(48296)
          , s = a(17229)
          , l = a(72278)
          , i = a(6059)
          , c = a(13352)
          , u = a(48278)
          , o = a(92725)
          , d = a(67338)
          , f = a(56471)
          , m = a(80526);
        function g(e) {
            let {data: t, loading: a} = (0,
            i.a)(e.userId);
            return a ? (0,
            r.jsx)(d.Z, {
                msg: "Loading user"
            }) : (0,
            r.jsxs)("div", {
                className: "flex flex-col gap-2",
                children: [(0,
                r.jsx)(u.default, {
                    src: f.Z,
                    alt: "banner"
                }), (0,
                r.jsx)("div", {
                    className: "card !border-danger",
                    children: (0,
                    r.jsx)("span", {
                        className: "text-danger",
                        children: "This account has been logged into from another device. Please enter your passphrase to use this account."
                    })
                }), (0,
                r.jsxs)("div", {
                    className: "card flex-col gap-1 items-center mb-2",
                    children: [(0,
                    r.jsxs)("p", {
                        className: "font-bold text-[18px] mb-4",
                        children: ["Henlo Henlo", " ", (0,
                        r.jsx)("span", {
                            className: "text-danger text-[18px]",
                            children: t.name
                        })]
                    }), (0,
                    r.jsxs)("div", {
                        className: "w-full flex flex-row gap-4 justify-between items-center",
                        children: [(0,
                        r.jsx)("span", {
                            className: "text-secondary",
                            children: "Name:"
                        }), t && (0,
                        r.jsxs)("div", {
                            className: "flex flex-row gap-1 items-center",
                            children: [(0,
                            r.jsx)(o.Z, {
                                userId: t._id
                            }), (0,
                            r.jsx)("p", {
                                className: "font-bold",
                                children: t.name
                            })]
                        })]
                    }), (0,
                    r.jsxs)("div", {
                        className: "w-full flex flex-row gap-4 justify-between items-center",
                        children: [(0,
                        r.jsx)("span", {
                            className: "text-secondary",
                            children: "Address:"
                        }), (0,
                        r.jsx)("div", {
                            className: "flex flex-row gap-1 items-center",
                            children: (0,
                            r.jsx)("p", {
                                className: "text-secondary",
                                children: (0,
                                m.Sy)(t.address, {
                                    maxLength: 4
                                })
                            })
                        })]
                    })]
                })]
            })
        }
        var h = a(13206)
          , p = a(2209)
          , x = a(32530)
          , v = a(59116)
          , w = a(11363);
        function y() {
            let {setCurrentKey: e} = (0,
            l.$$)()
              , {data: t} = (0,
            i.a)()
              , [a,n] = (0,
            c.useState)((0,
            p.OF)())
              , [u,d] = (0,
            c.useState)("")
              , [f,g] = (0,
            c.useState)(0)
              , [y,b] = (0,
            c.useState)(!1)
              , A = (0,
            s.i)({
                phrase: a
            })
              , {message: j} = (0,
            v.p)();
            (0,
            c.useEffect)(()=>{
                f > 0 && setTimeout(()=>{
                    g(f - 1)
                }
                , 1e3)
            }
            , [f]);
            let N = async()=>{
                try {
                    await (0,
                    x.Wt)({
                        serverId: t.server,
                        pubkey: A.publicKey
                    }),
                    e({
                        ...(0,
                        s.i)({
                            phrase: a
                        }),
                        phrase: a
                    }),
                    window.location.reload()
                } catch (e) {
                    j({
                        msg: e.response.data.message,
                        type: "error"
                    })
                } finally {
                    b(!1)
                }
            }
              , S = "I agree to change ".concat(t.name, "'s wallet");
            return (0,
            r.jsxs)("div", {
                className: "flex flex-col gap-4",
                children: [(0,
                r.jsx)("div", {
                    className: "card !border-danger",
                    children: (0,
                    r.jsxs)("span", {
                        className: "text-danger",
                        children: ["Generating a new passphrase will completely unbind your previous wallet with this Telegram account. ", (0,
                        r.jsx)("br", {}), " All processes associated with this Telegram ID will remain the same, but the wallet will be updated.", (0,
                        r.jsx)("br", {}), " Remember to save your passphrase to experience the BeraSig Wallet and Berachain Ecosystem in general."]
                    })
                }), (0,
                r.jsxs)("div", {
                    className: "card flex-col gap-1 items-center mb-2",
                    children: [(0,
                    r.jsxs)("p", {
                        className: "font-bold text-[18px] mb-4",
                        children: ["Henlo Henlo", " ", (0,
                        r.jsx)("span", {
                            className: "text-danger text-[18px]",
                            children: t.name
                        })]
                    }), (0,
                    r.jsxs)("div", {
                        className: "w-full flex flex-row gap-4 justify-between items-center",
                        children: [(0,
                        r.jsx)("span", {
                            className: "text-secondary",
                            children: "Name:"
                        }), t && (0,
                        r.jsxs)("div", {
                            className: "flex flex-row gap-1 items-center",
                            children: [(0,
                            r.jsx)(o.Z, {
                                userId: t._id
                            }), (0,
                            r.jsx)("p", {
                                className: "font-bold",
                                children: t.name
                            })]
                        })]
                    }), (0,
                    r.jsxs)("div", {
                        className: "w-full flex flex-row gap-4 justify-between items-center",
                        children: [(0,
                        r.jsx)("span", {
                            className: "text-secondary",
                            children: "Current Address:"
                        }), (0,
                        r.jsxs)("div", {
                            className: "flex flex-row gap-1 items-center",
                            children: [(0,
                            r.jsx)("p", {
                                className: "text-secondary",
                                children: (0,
                                m.Sy)(t.address, {
                                    maxLength: 4
                                })
                            }), (0,
                            r.jsx)(w.S, {
                                className: "w-4 text-secondary",
                                content: t.address,
                                onClick: ()=>{}
                            })]
                        })]
                    }), (0,
                    r.jsxs)("div", {
                        className: "w-full flex flex-row gap-4 justify-between items-center",
                        children: [(0,
                        r.jsx)("span", {
                            className: "text-secondary",
                            children: "New address:"
                        }), (0,
                        r.jsxs)("div", {
                            className: "flex flex-row gap-1 items-center",
                            children: [(0,
                            r.jsx)("p", {
                                className: "text-secondary",
                                children: (0,
                                m.Sy)(A.address.toLowerCase(), {
                                    maxLength: 4
                                })
                            }), (0,
                            r.jsx)(w.S, {
                                className: "w-4 text-secondary",
                                content: A.address.toLowerCase(),
                                onClick: ()=>{}
                            })]
                        })]
                    })]
                }), (0,
                r.jsxs)(c.Fragment, {
                    children: [(0,
                    r.jsx)("div", {
                        className: "flex flex-col gap-2",
                        children: (0,
                        r.jsx)("div", {
                            className: "group-input !rounded-2xl",
                            children: (0,
                            r.jsx)("textarea", {
                                className: "bg-body min-h-20 text-secondary font-medium",
                                value: u,
                                rows: 1,
                                onChange: e=>d(e.target.value),
                                placeholder: S
                            })
                        })
                    }), (0,
                    r.jsx)("div", {
                        className: "flex flex-col gap-4",
                        children: (0,
                        r.jsxs)("button", {
                            className: "btn flex-row gap-[10px] p-4 w-full",
                            disabled: u !== S || y,
                            onClick: N,
                            children: [(0,
                            r.jsx)(h.Z, {
                                className: "w-6 text-white"
                            }), (0,
                            r.jsx)("h6", {
                                className: "font-bold text-white",
                                children: u !== S ? "Enter confirm text" : "Change Wallet"
                            }), y && (0,
                            r.jsx)("span", {
                                className: "loading"
                            })]
                        })
                    })]
                })]
            })
        }
        function b() {
            let {setCurrentKey: e} = (0,
            l.$$)()
              , {data: t} = (0,
            i.a)()
              , [a,u] = (0,
            c.useState)("")
              , [o,d] = (0,
            c.useState)("")
              , [f,m] = (0,
            c.useState)(!1);
            return ((0,
            c.useEffect)(()=>{
                try {
                    if (!a)
                        throw Error("Enter passphrase");
                    let e = (0,
                    s.i)({
                        phrase: a
                    });
                    if (!e)
                        throw Error("Invalid passphrase");
                    if (t.address.toLowerCase() !== e.address.toLowerCase())
                        throw Error("Address does not match");
                    d("")
                } catch (e) {
                    d(e.message)
                }
            }
            , [a, e, t.address]),
            f) ? (0,
            r.jsx)(y, {}) : (0,
            r.jsxs)("div", {
                className: "flex flex-col gap-4",
                children: [(0,
                r.jsx)(g, {
                    userId: t._id
                }), (0,
                r.jsxs)(c.Fragment, {
                    children: [(0,
                    r.jsx)("div", {
                        className: "flex flex-col gap-6",
                        children: (0,
                        r.jsx)("div", {
                            className: "group-input !rounded-2xl",
                            children: (0,
                            r.jsx)("textarea", {
                                className: "bg-body min-h-20 text-secondary font-medium",
                                value: a,
                                rows: 3,
                                onChange: e=>u(e.target.value),
                                placeholder: "skirt melt company ..."
                            })
                        })
                    }), (0,
                    r.jsxs)("div", {
                        className: "flex flex-col gap-4",
                        children: [(0,
                        r.jsx)("p", {
                            className: "text-secondary text-end font-bold underline cursor-pointer",
                            onClick: ()=>m(!0),
                            children: "Forgot your passphrase?"
                        }), (0,
                        r.jsxs)("button", {
                            className: "btn flex-row gap-[10px] p-4 w-full",
                            disabled: !!o,
                            onClick: ()=>e({
                                ...(0,
                                s.i)({
                                    phrase: a
                                }),
                                phrase: a
                            }),
                            children: [(0,
                            r.jsx)(n.Z, {
                                className: "w-6 text-white"
                            }), (0,
                            r.jsx)("h6", {
                                className: "font-bold text-white",
                                children: o || "Import Wallet"
                            })]
                        })]
                    })]
                })]
            })
        }
    },
    92725: function(e, t, a) {
        "use strict";
        a.d(t, {
            Z: function() {
                return l
            }
        });
        var r = a(45615)
          , n = a(6059)
          , s = a(42784);
        function l(e) {
            let {userId: t, size: a=24} = e
              , {data: l} = (0,
            n.a)(t);
            return (0,
            r.jsx)(s.Z, {
                className: "rounded-full",
                src: l.thumbnail,
                size: a,
                fallbackSalt: l.name
            })
        }
    },
    11363: function(e, t, a) {
        "use strict";
        a.d(t, {
            S: function() {
                return u
            },
            T: function() {
                return o
            }
        });
        var r = a(45615)
          , n = a(13352)
          , s = a(39839)
          , l = a.n(s)
          , i = a(63452)
          , c = a(59116);
        function u(e) {
            let {content: t, className: a, onClick: s} = e
              , c = (0,
            n.useCallback)(async(e,t)=>{
                t.stopPropagation(),
                l()(e),
                s()
            }
            , [s]);
            return (0,
            r.jsx)("div", {
                className: "flex flex-row gap-1 cursor-pointer",
                onClick: e=>c(t, e),
                children: (0,
                r.jsx)(i.Z, {
                    className: a
                })
            })
        }
        function o(e) {
            let {content: t, children: a} = e
              , {message: s} = (0,
            c.p)()
              , i = (0,
            n.useCallback)(async(e,t)=>{
                t.stopPropagation(),
                l()(e),
                s({
                    msg: "Copy to clipboard",
                    type: "success"
                })
            }
            , [s]);
            return (0,
            r.jsx)("div", {
                className: "cursor-pointer",
                onClick: e=>i(t, e),
                children: a
            })
        }
    },
    15019: function(e, t, a) {
        "use strict";
        var r = a(45615)
          , n = a(48278)
          , s = a(73743);
        t.Z = e=>(0,
        r.jsxs)("div", {
            className: "flex flex-col gap-4 ",
            children: [(0,
            r.jsx)(n.default, {
                src: s.Z,
                alt: "welcome"
            }), (0,
            r.jsxs)("div", {
                className: "flex flex-col gap-4 text-center p-4",
                children: [(0,
                r.jsx)("h5", {
                    className: "",
                    children: "Whoops! Something went wrong"
                }), (0,
                r.jsx)("div", {}), (0,
                r.jsx)("div", {
                    className: "text-[13px] leading-8",
                    children: e.msg
                }), (0,
                r.jsx)("button", {
                    className: "btn p-5",
                    children: (0,
                    r.jsx)("h5", {
                        className: "font-bold",
                        onClick: ()=>{
                            window.location.reload()
                        }
                        ,
                        children: "Reload App"
                    })
                })]
            })]
        })
    },
    42784: function(e, t, a) {
        "use strict";
        a.d(t, {
            Z: function() {
                return i
            }
        });
        var r = a(45615)
          , n = a(48278)
          , s = a(13352)
          , l = a(80526);
        function i(e) {
            let {src: t, fallbackSrc: a, fallbackSalt: i="", size: c, ...u} = e
              , [o,d] = (0,
            s.useState)(0)
              , f = [t, a].filter(e=>!!e)[o];
            return f ? (0,
            r.jsx)(n.default, {
                alt: "avatar",
                width: c,
                height: c,
                src: f,
                className: "rounded-full",
                onLoadingComplete: e=>{
                    0 === e.naturalWidth && d(o + 1)
                }
                ,
                onError: ()=>{
                    d(o + 1)
                }
                ,
                ...u
            }) : (0,
            r.jsx)("div", {
                style: {
                    width: c,
                    height: c,
                    backgroundColor: (0,
                    l.p)(i)
                },
                className: "rounded-full flex flex-col items-center justify-center",
                children: (0,
                r.jsx)("p", {
                    className: "capitalize",
                    style: {
                        fontSize: c / 2,
                        color: "white"
                    },
                    children: i.slice(0, 1)
                })
            })
        }
    },
    67338: function(e, t, a) {
        "use strict";
        var r = a(45615);
        a(88563),
        t.Z = e=>(0,
        r.jsxs)("div", {
            className: "loading-page",
            style: {
                height: (null == e ? void 0 : e.height) ? e.height : e.page ? "calc(100vh - 140px);" : void 0
            },
            children: [(0,
            r.jsx)("div", {
                className: "loader"
            }), (0,
            r.jsx)("div", {
                className: "text-loader"
            }), (0,
            r.jsx)("span", {
                className: "text-secondary",
                style: {
                    fontSize: 10
                },
                children: e.msg
            })]
        })
    },
    51733: function(e, t, a) {
        "use strict";
        a.d(t, {
            Z: function() {
                return u
            }
        });
        var r = a(45615)
          , n = a(48278)
          , s = a(13352)
          , l = a(10779)
          , i = a(45638)
          , c = a(72745);
        function u(e) {
            let {type: t="success"} = e
              , a = (0,
            s.useMemo)(()=>{
                switch (t) {
                case "success":
                    return l.default;
                case "error":
                    return i.default;
                case "warning":
                    return c.default
                }
            }
            , [t]);
            return (0,
            r.jsx)(n.default, {
                src: a,
                alt: t
            })
        }
    },
    92517: function(e, t, a) {
        "use strict";
        a.d(t, {
            default: function() {
                return n
            }
        });
        let r = "production";
        var n = {
            env: r,
            cluster: {
                development: {
                    beraSigServer: "http://localhost:9998",
                    serverId: "6666d1d03f6375581720e70e"
                },
                staging: {
                    beraSigServer: "https://berasig-server-staging.onrender.com",
                    serverId: "6666d1d03f6375581720e70e"
                },
                production: {
                    beraSigServer: "https://berasig-server-production.onrender.com",
                    serverId: "6666d1d03f6375581720e70e"
                }
            }[r]
        }
    },
    60070: function(e, t, a) {
        "use strict";
        a.d(t, {
            CE: function() {
                return s
            },
            DX: function() {
                return l
            },
            V6: function() {
                return i
            },
            _J: function() {
                return c
            },
            xn: function() {
                return n
            }
        });
        var r = a(78623);
        let n = (e,t)=>{
            let a = new Map;
            return e.forEach(e=>{
                (null == e ? void 0 : e[t]) && a.set(e[t], e)
            }
            ),
            a
        }
          , s = e=>e && Number(e) ? .001 > Number(e) ? "<0.001" : Number(e) > 100 ? (0,
        r.uR)(e).format("0,0.[0]") : Number(e) > 10 ? (0,
        r.uR)(e).format("0,0.[00]") : (0,
        r.uR)(e).format("0,0.[000]") : "0"
          , l = e=>parseFloat(e.toFixed(9))
          , i = (e,t)=>Math.floor(Math.random() * (t - e + 1) + e);
        function c(e) {
            let t = new Date
              , a = new Date(e)
              , r = Math.floor((t.getTime() - a.getTime()) / 1e3);
            return r < 60 ? "1m" : r < 3600 ? Math.floor(r / 60) + "m" : r < 86400 ? Math.floor(r / 3600) + "h" : r < 604800 ? Math.floor(r / 86400) + "d" : r < 2592e3 ? Math.floor(r / 604800) + "w" : r < 31536e3 ? Math.floor(r / 2592e3) + "mo" : Math.floor(r / 31536e3) + "y"
        }
    },
    17229: function(e, t, a) {
        "use strict";
        a.d(t, {
            i: function() {
                return c
            }
        });
        var r = a(4159)
          , n = a(58742)
          , s = a(90959)
          , l = a(2209)
          , i = a(7851);
        let c = e=>{
            let {phrase: t, privateKey: a} = e
              , c = a;
            if (t && (0,
            l._I)(t)) {
                let e = n.gk.fromPhrase(t);
                if (!e)
                    throw Error("Passphrase is invalid!");
                c = e.privateKey
            }
            if (!c)
                throw Error("Private key is invalid!");
            c = c.startsWith("0x") ? c.slice(2) : c;
            let u = (0,
            r.$3)(c, !0)
              , o = (0,
            i.encode)(u)
              , d = (0,
            s.d)("0x".concat(c));
            return {
                publicKey: o,
                privateKey: c,
                address: d
            }
        }
    },
    52272: function(e, t, a) {
        "use strict";
        a.d(t, {
            U: function() {
                return i
            }
        });
        var r = a(13352)
          , n = a(50529)
          , s = a(70978)
          , l = a(60070);
        let i = e=>{
            let {data: t} = (0,
            s.Af)(e)
              , a = (0,
            n.q)(e=>e.skills)
              , i = (0,
            r.useMemo)(()=>{
                if (!e)
                    return {
                        luckyRate: 0,
                        speedRate: 0,
                        sizeRate: 0,
                        memberSize: 0
                    };
                let r = (0,
                l.xn)(a, "_id")
                  , n = {
                    luckyRate: 0,
                    speedRate: 0,
                    sizeRate: 0,
                    memberSize: 0
                };
                for (let e of (null == t ? void 0 : t.skills) || []) {
                    let t = r.get(e);
                    n.luckyRate += t.attribute.luckyBonusRate || 0,
                    n.speedRate += t.attribute.miningSpeedBonusRate || 0,
                    n.sizeRate += t.attribute.miningSizeBonusRate || 0,
                    n.memberSize += t.attribute.memberSize || 0
                }
                return n
            }
            , [null == t ? void 0 : t.skills, e, a]);
            return (0,
            r.useMemo)(()=>({
                data: i,
                loading: !1
            }), [i])
        }
    },
    34992: function(e, t, a) {
        "use strict";
        a.d(t, {
            $O: function() {
                return o
            },
            UC: function() {
                return u
            },
            ZM: function() {
                return c
            },
            mr: function() {
                return d
            }
        });
        var r = a(13352);
        a(60070);
        var n = a(50529);
        a(70978),
        a(6059);
        var s = a(61590)
          , l = a(86069)
          , i = a(1049);
        let c = e=>(0,
        n.q)(t=>t.skills.find(t=>t._id === e))
          , u = e=>{
            let t = c(e);
            return c(null == t ? void 0 : t.nextSkillId)
        }
          , o = e=>{
            let {queryClient: t} = (0,
            l.o)()
              , {data: a, isLoading: r} = (0,
            s.a)({
                queryKey: ["".concat(l.q.guildChequeSkills, ":").concat(e)],
                queryFn: async()=>{
                    let a = await (0,
                    i.yr)(e);
                    for (let e of a)
                        await t.setQueryData(["".concat(l.q.guildChequeSkill, ":").concat(e._id)], e);
                    return a
                }
                ,
                enabled: !!e
            });
            return {
                data: a,
                loading: r
            }
        }
          , d = e=>{
            let {queryClient: t} = (0,
            l.o)()
              , {data: a, isLoading: n} = (0,
            s.a)({
                queryKey: ["".concat(l.q.guildChequeSkill, ":").concat(e)],
                queryFn: async()=>await (0,
                i.eF)(e),
                enabled: !!e
            });
            return {
                data: a,
                isLoading: n,
                setCheque: (0,
                r.useCallback)(async e=>{
                    await t.setQueryData(["".concat(l.q.guildChequeSkill, ":").concat(e._id)], e)
                }
                , [t])
            }
        }
    },
    86069: function(e, t, a) {
        "use strict";
        a.d(t, {
            o: function() {
                return i
            },
            q: function() {
                return n
            }
        });
        var r, n, s = a(31858), l = a(13352);
        (r = n || (n = {})).items = "items",
        r.users = "users",
        r.guilds = "guilds",
        r.guildChequeSkills = "guildChequeSkills",
        r.guildChequeSkill = "guildChequeSkill";
        let i = ()=>{
            let e = (0,
            s.NL)();
            return {
                invalidateQueries: (0,
                l.useCallback)(t=>{
                    for (let a of t)
                        e.invalidateQueries({
                            predicate: e=>{
                                let {queryKey: t} = e;
                                return String(t[0]).startsWith(a)
                            }
                            ,
                            type: "all"
                        })
                }
                , [e]),
                queryClient: e
            }
        }
    },
    91225: function(e, t, a) {
        "use strict";
        a.d(t, {
            _: function() {
                return c
            }
        });
        var r = a(13352)
          , n = a(50529)
          , s = a(6059)
          , l = a(52272)
          , i = a(60070);
        let c = e=>{
            let t = (0,
            s.a)(e)
              , a = (0,
            n.q)(e=>e.items)
              , c = (0,
            l.U)(t.data.guild)
              , u = (0,
            r.useMemo)(()=>{
                let e = {
                    speed: 0,
                    size: 0,
                    ref: 0
                };
                if (t.loading)
                    return e;
                let r = (0,
                i.xn)(a, "_id");
                for (let a of t.data.items) {
                    let t = r.get(a);
                    e.size += t.attribute.tokenSize || 0,
                    e.ref += t.attribute.refSize || 0,
                    e.speed += t.attribute.speed || 0
                }
                return e.size += e.size * c.data.sizeRate,
                e.speed += e.speed * c.data.speedRate,
                e
            }
            , [c.data.sizeRate, c.data.speedRate, a, t.data.items, t.loading]);
            return (0,
            r.useMemo)(()=>({
                data: u,
                loading: t.loading
            }), [u, t.loading])
        }
    },
    50529: function(e, t, a) {
        "use strict";
        a.d(t, {
            Y: function() {
                return x
            },
            default: function() {
                return w
            },
            q: function() {
                return p
            }
        });
        var r = a(45615)
          , n = a(13352)
          , s = a(82216)
          , l = a(25652)
          , i = a(9680)
          , c = a(31858)
          , u = a(29117)
          , o = a.n(u)
          , d = a(67338)
          , f = a(15019)
          , m = a(90047)
          , g = a(80526)
          , h = a(92517);
        let p = (0,
        l.Ue)()((0,
        s.tJ)(e=>({
            serverName: "",
            chainId: "",
            serverId: "",
            owner: "",
            fee: "0",
            news: "",
            readNews: "",
            items: [],
            skills: [],
            setApp: t=>e({
                ...t
            })
        }), {
            name: "app-store",
            storage: (0,
            s.FL)(()=>o())
        }))
          , x = ()=>p()
          , v = new i.S({
            defaultOptions: {
                queries: {
                    refetchOnWindowFocus: !1,
                    refetchOnMount: !1,
                    staleTime: 3e5
                }
            }
        });
        function w(e) {
            let {children: t} = e
              , {setApp: a} = p()
              , [s,l] = (0,
            n.useState)("")
              , [i,u] = (0,
            n.useState)(!0)
              , [o,x] = (0,
            n.useState)(!1)
              , w = (0,
            n.useCallback)(async()=>{
                try {
                    let {server: e, items: t, skills: r} = await (0,
                    m.t)(h.default.cluster.serverId);
                    a({
                        serverName: e.name,
                        serverId: h.default.cluster.serverId,
                        chainId: e.chainId,
                        owner: e.owner,
                        fee: e.fee,
                        news: e.news,
                        items: t,
                        skills: r
                    })
                } catch (e) {
                    l(e.message)
                } finally {
                    u(!1)
                }
            }
            , [a]);
            return ((0,
            g.Nr)(w, 300, [w]),
            (0,
            n.useEffect)(()=>{
                "false" !== localStorage.getItem("soundTrack") && (document.addEventListener("click", ()=>{
                    var e = new Audio("https://www.bensound.com/bensound-music/bensound-longnight.mp3");
                    e.volume = .05,
                    e.addEventListener("ended", function() {
                        this.currentTime = 0,
                        this.play()
                    }, !1),
                    e.play(),
                    document.addEventListener("visibilitychange", function() {
                        document.hidden ? e.pause() : e.play()
                    })
                }
                , {
                    once: !0
                }),
                document.addEventListener("click", function(e) {
                    let t = document.createElement("div");
                    t.className = "ripple",
                    t.style.transform = "translate(".concat(e.x, "px, ").concat(e.y, "px)"),
                    document.body.appendChild(t),
                    t.addEventListener("animationend", function() {
                        t.remove()
                    })
                }))
            }
            , []),
            (0,
            n.useEffect)(()=>{
                let e;
                let t = ()=>{
                    document.hidden ? e = setTimeout(()=>{
                        x(!0)
                    }
                    , 2e4) : (clearTimeout(e),
                    x(!1))
                }
                ;
                return document.addEventListener("visibilitychange", t),
                ()=>{
                    document.removeEventListener("visibilitychange", t)
                }
            }
            , []),
            o) ? null : s ? (0,
            r.jsx)(f.Z, {
                msg: s
            }) : i ? (0,
            r.jsx)(d.Z, {
                msg: "Loading server data (3/6)"
            }) : (0,
            r.jsx)(c.aH, {
                client: v,
                children: t
            })
        }
    },
    70978: function(e, t, a) {
        "use strict";
        a.d(t, {
            Af: function() {
                return j
            },
            default: function() {
                return k
            },
            fE: function() {
                return N
            },
            lJ: function() {
                return S
            },
            pU: function() {
                return b
            }
        });
        var r = a(45615)
          , n = a(13352)
          , s = a(25652)
          , l = a(4049)
          , i = a(61590)
          , c = a(32530)
          , u = a(27904)
          , o = a(1049)
          , d = a(82216)
          , f = a(86069)
          , m = a(6059)
          , g = a(50087)
          , h = a(34992)
          , p = a(50529)
          , x = a(60070)
          , v = a(67338);
        let w = {
            _id: "",
            description: "",
            level: u.G.One,
            name: "",
            owner: "",
            deputies: [],
            server: "",
            totalMember: 0,
            totalToken: 0,
            userRequests: [],
            skills: [],
            chatLink: ""
        }
          , y = (0,
        s.Ue)()((0,
        d.tJ)(e=>({
            guild: w,
            setGuild: t=>e({
                guild: t
            }),
            updateGuild: t=>e((0,
            l.Uy)(e=>{
                let {guild: a} = e;
                Object.assign(a, t)
            }
            ))
        }), {
            name: "guild",
            storage: (0,
            d.FL)(()=>localStorage)
        }))
          , b = e=>{
            let {data: t} = (0,
            m.a)(e);
            return {
                speed: A({
                    guildId: t.guild,
                    category: g.D.Speed
                }),
                size: A({
                    guildId: t.guild,
                    category: g.D.Size
                })
            }
        }
          , A = e=>{
            let {guildId: t, category: a} = e
              , r = (0,
            h.$O)(t)
              , {skills: s} = (0,
            p.Y)();
            return (0,
            n.useMemo)(()=>{
                if (!r.data)
                    return null;
                let e = (0,
                x.xn)(s, "_id");
                for (let t of r.data) {
                    let r = e.get(t.skill);
                    if ((null == r ? void 0 : r.category) === a)
                        return r
                }
                return null
            }
            , [a, r.data, s])
        }
          , j = e=>{
            let {setGuild: t} = y()
              , {queryClient: a} = (0,
            f.o)()
              , r = (0,
            m.a)()
              , s = (0,
            i.a)({
                queryKey: ["".concat(f.q.guilds, ":").concat(e)],
                queryFn: async()=>{
                    if (!e)
                        return w;
                    let a = await (0,
                    o.Sk)(e);
                    return a._id === r.data.guild && t(a),
                    a
                }
                ,
                enabled: !!e
            })
              , l = (0,
            n.useCallback)(async e=>{
                await a.setQueryData(["".concat(f.q.guilds, ":").concat(e._id)], e),
                e._id === r.data.guild && t(e)
            }
            , [a, t, r.data.guild]);
            return {
                data: s.data || w,
                loading: s.isLoading,
                setGuild: l
            }
        }
          , N = e=>{
            let {search: t, page: a, perPage: r} = e
              , {queryClient: s} = (0,
            f.o)()
              , l = (0,
            i.a)({
                queryKey: ["".concat(f.q.guilds)],
                queryFn: async()=>{
                    let e = (a || 0) * (r || 10)
                      , n = await (0,
                    o.n6)({
                        limit: r,
                        offset: e,
                        search: t
                    });
                    for (let e of n.items)
                        await s.setQueryData(["".concat(f.q.guilds, ":").concat(e._id)], e);
                    return n
                }
            })
              , c = (0,
            n.useCallback)(async()=>{
                try {
                    await s.invalidateQueries({
                        queryKey: ["".concat(f.q.guilds)]
                    })
                } catch (e) {
                    console.log("get guilds errors: ", e.message)
                }
            }
            , [s])
              , u = (0,
            n.useCallback)(async e=>{
                try {
                    let t = (a || 0) * (r || 10)
                      , n = await (0,
                    o.n6)({
                        limit: r,
                        offset: t,
                        search: e
                    });
                    for (let e of n.items)
                        await s.setQueryData(["".concat(f.q.guilds, ":").concat(e._id)], e);
                    return n
                } catch (e) {
                    console.log("find guilds errors: ", e.message)
                }
            }
            , [a, r, s]);
            return {
                data: l.data,
                loading: l.isLoading,
                getGuilds: c,
                refetch: l.refetch,
                findGuilds: u
            }
        }
          , S = e=>{
            let {guildId: t, page: a, perPage: r, sortOrder: n} = e
              , {queryClient: s} = (0,
            f.o)();
            return (0,
            i.a)({
                queryKey: ["guild-members", r, t, n],
                queryFn: async()=>{
                    let e = (a || 0) * (r || 10)
                      , l = await (0,
                    c.Rf)({
                        guild: t,
                        offset: e,
                        limit: r,
                        sort: "totalGuildDonate",
                        sortOrder: n
                    });
                    for (let e of l.items)
                        await s.setQueryData(["".concat(f.q.users, ":").concat(e._id)], e);
                    return l
                }
                ,
                enabled: !!t
            })
        }
        ;
        function k(e) {
            let {children: t} = e
              , {setGuild: a} = y()
              , {data: s} = (0,
            m.a)()
              , [l,i] = (0,
            n.useState)(!0)
              , c = (0,
            n.useCallback)(async()=>{
                if (!(null == s ? void 0 : s._id))
                    return a(w);
                try {
                    if (!s.guild)
                        return a(w);
                    let e = await (0,
                    o.Sk)(s.guild);
                    a(e)
                } catch (e) {
                    console.log(e)
                } finally {
                    i(!1)
                }
            }
            , [a, null == s ? void 0 : s._id, s.guild]);
            return ((0,
            n.useEffect)(()=>{
                c()
            }
            , [c]),
            l) ? (0,
            r.jsx)(v.Z, {
                msg: "Loading guilds (5/6)"
            }) : s.guild ? (0,
            r.jsx)(E, {
                children: t
            }) : (0,
            r.jsx)(n.Fragment, {
                children: t
            })
        }
        function E(e) {
            let {children: t} = e
              , {data: a} = (0,
            m.a)();
            return (0,
            h.$O)(a.guild).loading ? (0,
            r.jsx)(v.Z, {
                msg: "Loading skills (6/6)"
            }) : (0,
            r.jsx)(n.Fragment, {
                children: t
            })
        }
    },
    72278: function(e, t, a) {
        "use strict";
        a.d(t, {
            $$: function() {
                return g
            },
            default: function() {
                return h
            },
            kS: function() {
                return m
            }
        });
        var r = a(45615)
          , n = a(13352)
          , s = a(25652)
          , l = a(2209)
          , i = a(29117)
          , c = a(17229)
          , u = a(82216)
          , o = a(67338);
        let d = {
            address: "",
            phrase: "",
            privateKey: "",
            publicKey: ""
        }
          , f = (0,
        s.Ue)()((0,
        u.tJ)(e=>({
            privateKey: void 0,
            setPrivateKey: t=>e({
                privateKey: t,
                initialized: !0
            }),
            initialized: !1,
            _hasHydrated: !1
        }), {
            name: "ZUSTAND_KEYS",
            storage: (0,
            u.FL)(()=>i),
            onRehydrateStorage: ()=>()=>{
                f.setState({
                    _hasHydrated: !0
                })
            }
        }))
          , m = ()=>{
            let {privateKey: e} = f();
            return {
                currentKey: (0,
                n.useMemo)(()=>e || d, [e])
            }
        }
          , g = ()=>{
            let {setPrivateKey: e, privateKey: t} = f();
            return {
                createPrivateKey: (0,
                n.useCallback)(()=>{
                    if (null == t ? void 0 : t.privateKey)
                        return (0,
                        c.i)({
                            privateKey: t.privateKey
                        });
                    let a = (0,
                    l.OF)()
                      , r = (0,
                    c.i)({
                        phrase: a
                    });
                    return e({
                        ...r,
                        phrase: a
                    }),
                    r
                }
                , [null == t ? void 0 : t.privateKey, e]),
                privateKey: t,
                setCurrentKey: e
            }
        }
        ;
        function h(e) {
            let {children: t} = e;
            return f(e=>e._hasHydrated) ? (0,
            r.jsx)(n.Fragment, {
                children: t
            }) : (0,
            r.jsx)(o.Z, {
                msg: "Loading wallet"
            })
        }
    },
    13317: function(e, t, a) {
        "use strict";
        a.d(t, {
            TelegramProvider: function() {
                return h
            },
            wA: function() {
                return p
            }
        });
        var r = a(45615)
          , n = a(13352)
          , s = a(67338)
          , l = a(74880)
          , i = a(25652)
          , c = a(82216)
          , u = a(29117)
          , o = a.n(u)
          , d = a(80526)
          , f = a(66442)
          , m = a(9351);
        let g = (0,
        i.Ue)()((0,
        c.tJ)(e=>({
            setStore: t=>{
                let {webApp: a, webAppUser: r} = t;
                return e({
                    webApp: a,
                    webAppUser: r
                })
            }
        }), {
            name: "ZUSTAND_TELEGRAM",
            storage: (0,
            c.FL)(()=>o())
        }));
        function h(e) {
            let {children: t} = e
              , a = g()
              , i = p()
              , c = (0,
            l.useRouter)()
              , u = (0,
            n.useCallback)(()=>{
                try {
                    let e = window.Telegram
                      , t = null == e ? void 0 : e.WebApp;
                    t && (t.ready(),
                    t.expand(),
                    t.BackButton.show(),
                    t.onEvent("backButtonClicked", ()=>{
                        c.back()
                    }
                    ),
                    t.isClosingConfirmationEnabled = !0,
                    (0,
                    f.QV)({
                        teleAuth: t.initData
                    }),
                    a.setStore({
                        webApp: t,
                        webAppUser: t.initDataUnsafe.user
                    }))
                } catch (e) {
                    console.log("error", e)
                } finally {}
            }
            , [c, a]);
            return ((0,
            d.Nr)(u, 300, [u]),
            i.id) ? (0,
            r.jsx)(r.Fragment, {
                children: t
            }) : (0,
            r.jsx)(s.Z, {
                msg: "Loading Telegram (2/6)"
            })
        }
        let p = ()=>{
            var e;
            let {webAppUser: t, webApp: a} = g()
              , r = (0,
            l.useSearchParams)();
            return (0,
            n.useMemo)(()=>{
                var e, n;
                let s = r.get("tgWebAppStartParam") || (null == a ? void 0 : null === (e = a.initDataUnsafe) || void 0 === e ? void 0 : e.start_param) || ""
                  , l = "";
                t && (l = "".concat(t.first_name, " ").concat(t.last_name).trim()),
                "berachain_ecosystem" === s && (s = "66670f70ea503f89b906aa8c");
                let i = {
                    id: (null == t ? void 0 : t.id) || 0,
                    name: l,
                    username: (null == t ? void 0 : t.username) || (null == t ? void 0 : null === (n = t.id) || void 0 === n ? void 0 : n.toString()) || "",
                    referrer: s,
                    isPremium: !!(null == t ? void 0 : t.is_premium),
                    thumbnail: (null == t ? void 0 : t.photo_url) || "",
                    initData: (null == a ? void 0 : a.initData) || ""
                };
                return m.env.NEXT_PUBLIC_TELEGRAM_USERNAME && m.env.NEXT_PUBLIC_TELEGRAM_ID && (i.username = m.env.NEXT_PUBLIC_TELEGRAM_USERNAME,
                i.name = m.env.NEXT_PUBLIC_TELEGRAM_USERNAME,
                i.id = Number(m.env.NEXT_PUBLIC_TELEGRAM_ID)),
                i
            }
            , [r, null == a ? void 0 : a.initData, null == a ? void 0 : null === (e = a.initDataUnsafe) || void 0 === e ? void 0 : e.start_param, t])
        }
    },
    59116: function(e, t, a) {
        "use strict";
        a.d(t, {
            p: function() {
                return l
            }
        });
        var r = a(45615);
        a(13352);
        var n = a(53435)
          , s = a(51733);
        let l = ()=>({
            message: e=>{
                let {msg: t, type: a} = e;
                return (0,
                n.default)(t, {
                    icon: (0,
                    r.jsx)(s.Z, {
                        type: a
                    }),
                    className: "hot-toast hot-toast-".concat(a)
                })
            }
        })
    },
    6059: function(e, t, a) {
        "use strict";
        a.d(t, {
            L: function() {
                return j
            },
            a: function() {
                return N
            },
            default: function() {
                return S
            }
        });
        var r = a(45615)
          , n = a(13352)
          , s = a(25652)
          , l = a(82216)
          , i = a(4049)
          , c = a(61590)
          , u = a(1464)
          , o = a(15019)
          , d = a(67338)
          , f = a(60346)
          , m = a(95471)
          , g = a(32530)
          , h = a(86069)
          , p = a(50529)
          , x = a(13317)
          , v = a(72278)
          , w = a(74880)
          , y = a(66442)
          , b = a(80526);
        let A = {
            _id: "",
            address: "",
            createdAt: "",
            guild: "",
            items: [],
            lastClaimAt: new Date,
            name: "",
            pubkey: "",
            referrer: "",
            server: "",
            tokenBalance: 0,
            totalTokenBonus: 0,
            totalTokenClaimed: 0,
            totalTokenEarned: 0,
            totalQuestClaimed: 0,
            totalTokenStolen: 0,
            username: "",
            telegramId: 0,
            isPremium: !1,
            thumbnail: "",
            totalReferral: 0,
            guildRequests: [],
            totalGuildDonate: 0,
            stolenBy: [],
            ip: "",
            userAgent: "",
            guildJoinedAt: "",
            updatedAt: "",
            takeTokenUpdateAt: new Date,
            takeTokenNonce: 0,
            takeTokenTotal: 0,
            nonce: 0,
            banned: !1
        }
          , j = (0,
        s.Ue)()((0,
        l.tJ)(e=>({
            user: A,
            setUser: t=>e({
                user: t
            }),
            updateUser: t=>e((0,
            i.Uy)(e=>{
                let {user: a} = e;
                Object.assign(a, t)
            }
            ))
        }), {
            name: "user",
            storage: (0,
            l.FL)(()=>localStorage)
        }))
          , N = e=>{
            let {user: t, setUser: a} = j()
              , r = e || (null == t ? void 0 : t._id)
              , {queryClient: s} = (0,
            h.o)()
              , l = (0,
            c.a)({
                queryKey: ["".concat(h.q.users, ":").concat(r)],
                queryFn: async()=>{
                    let e = await (0,
                    g.PR)(r);
                    return r === (null == t ? void 0 : t._id) && a(e),
                    e
                }
                ,
                enabled: !!r
            })
              , i = (0,
            n.useCallback)(e=>{
                s.setQueryData(["".concat(h.q.users, ":").concat(e._id)], e),
                e._id === (null == t ? void 0 : t._id) && a(e)
            }
            , [s, a, null == t ? void 0 : t._id]);
            return {
                data: l.data || A,
                loading: l.isLoading,
                setUser: i
            }
        }
        ;
        function S(e) {
            var t, a;
            let {children: s} = e
              , {user: l, setUser: i} = j()
              , c = (0,
            v.$$)()
              , {serverId: h} = (0,
            p.q)()
              , N = (0,
            x.wA)()
              , S = (0,
            w.useRouter)()
              , [k,E] = (0,
            n.useState)(!0)
              , I = (0,
            n.useCallback)(async function() {
                var e, t;
                let a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date().toISOString();
                if (null === (e = c.privateKey) || void 0 === e ? void 0 : e.privateKey) {
                    let e = new u.w(null === (t = c.privateKey) || void 0 === t ? void 0 : t.privateKey)
                      , r = "".concat(l._id, ":").concat(h, ":").concat(a)
                      , n = await e.signMessage(r);
                    (0,
                    y.QV)({
                        serverId: h,
                        userId: l._id,
                        bccToken: n,
                        lifeTime: a
                    })
                }
            }, [null === (t = c.privateKey) || void 0 === t ? void 0 : t.privateKey, h, l._id]);
            (0,
            b.Nr)(I, 1e3, [I]),
            (0,
            n.useEffect)(()=>{
                let e = setInterval(()=>{
                    I(new Date().toISOString())
                }
                , 3e5);
                return ()=>{
                    clearInterval(e)
                }
            }
            , [I]);
            let T = (0,
            n.useCallback)(async()=>{
                try {
                    if (!N.id)
                        throw Error("Invalid telegram account");
                    let e = await (0,
                    g.d0)(h, N.id);
                    if (i(e || A),
                    e)
                        return S.push("/home/earn")
                } catch (e) {
                    console.log("error", e)
                } finally {
                    E(!1)
                }
            }
            , [h, N.id, i, S]);
            return ((0,
            b.Nr)(T, 500, [T]),
            k) ? (0,
            r.jsx)(d.Z, {
                msg: "Loading user (4/6)"
            }) : N.id ? l._id ? l.address.toLowerCase() !== (null === (a = c.privateKey) || void 0 === a ? void 0 : a.address.toLowerCase()) ? (0,
            r.jsx)(m.default, {}) : l.telegramId && l.telegramId !== N.id ? (0,
            r.jsx)(o.Z, {
                msg: "Invalid telegram account with user"
            }) : s : (0,
            r.jsx)(f.default, {}) : (0,
            r.jsx)(o.Z, {
                msg: "Invalid telegram account"
            })
        }
    },
    80526: function(e, t, a) {
        "use strict";
        a.d(t, {
            Nr: function() {
                return c
            },
            Sy: function() {
                return n
            },
            p: function() {
                return s
            },
            sA: function() {
                return l
            }
        });
        var r = a(13352);
        let n = (e,t)=>{
            let a = (null == t ? void 0 : t.maxLength) || 3
              , r = (null == t ? void 0 : t.symbol) || "..."
              , n = (null == t ? void 0 : t.suffix) === void 0 || t.suffix;
            if (!e || e.length <= 2 * a)
                return e;
            let s = "".concat(r).concat(e.substring(e.length - a));
            return "".concat(e.substring(0, a)).concat(n ? s : "")
        }
          , s = (e,t)=>{
            let a = Math.floor(16777215 * Math.random());
            if (e) {
                a = 0;
                for (let t = 0; t < e.length; t++)
                    a = e.charCodeAt(t) + ((a << 5) - a)
            }
            var r = [0, 0, 0];
            for (let e = 0; e < 3; e++) {
                var n = a >> 8 * e & 255;
                r[e] = n
            }
            return "rgba(".concat(r[0], ", 100, ").concat(r[1], ",").concat(t || 1, ")")
        }
          , l = e=>new Promise(t=>setTimeout(t, e))
          , i = (e,t)=>{
            let a = (0,
            r.useRef)(!1)
              , n = (0,
            r.useRef)()
              , s = (0,
            r.useRef)(e)
              , l = (0,
            r.useCallback)(()=>a.current, [])
              , i = (0,
            r.useCallback)(()=>{
                a.current = !1,
                n.current && clearTimeout(n.current),
                n.current = setTimeout(()=>{
                    a.current = !0,
                    s.current()
                }
                , t)
            }
            , [t])
              , c = (0,
            r.useCallback)(()=>{
                a.current = null,
                n.current && clearTimeout(n.current)
            }
            , []);
            return (0,
            r.useEffect)(()=>{
                s.current = e
            }
            , [e]),
            (0,
            r.useEffect)(()=>(i(),
            c), [c, t, i]),
            [l, c, i]
        }
          , c = (e,t,a)=>{
            let[n,s,l] = i(e, t);
            return (0,
            r.useEffect)(l, a),
            [n, s]
        }
    },
    78623: function(e, t, a) {
        "use strict";
        a.d(t, {
            $q: function() {
                return l
            },
            T8: function() {
                return u
            },
            uR: function() {
                return c
            }
        });
        var r = a(70946)
          , n = a.n(r)
          , s = a(6882);
        let l = (e,t)=>{
            let[a,r] = i(e)
              , s = new (n())(10);
            return a.mul(s.pow(new (n())(t))).div(s.pow(new (n())(r)))
        }
          , i = e=>{
            let t = new (n())(10)
              , [a,r] = e.toString().split(".")
              , s = (r || "").length;
            return [new (n())(a).mul(t.pow(new (n())(s))).add(new (n())(r || "0")), s]
        }
          , c = e=>e ? (0,
        s.Z)(e) : (0,
        s.Z)("0")
          , u = (e,t)=>{
            let a = new (n())(10)
              , r = e.div(a.pow(new (n())(t)))
              , s = e.sub(r.mul(a.pow(new (n())(t))))
              , l = r.toString()
              , i = s.toString();
            for (; i.length < t; )
                i = "0" + i;
            return "" === (i = i.replace(/0+$/, "")) && (i = "0"),
            l + "." + i
        }
    },
    88563: function() {},
    72363: function() {},
    56471: function(e, t) {
        "use strict";
        t.Z = {
            src: "/_next/static/media/bear-group.0a1e7126.png",
            height: 1029,
            width: 1029,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AfT5+wDZ3uIGDxQODCHote4DLWAA/f/0C/XKdBaJvSPkAez2+nMNBwWCBgIA8frNnXgBES5h/RMlxfHGEch+SgDJAfH//zYO+PlX4d28ctTm9wAB/v4AI/rQzSdFgpzfCASlAQAAAAq0dQCJ2CWJbEIgE/oODh8B1Ma/BTgvMfMEQlQrAc3At2DOvrSf5xH3/Vgu+gP87Qn/7r/HARAxWuMrZHA9AeHKyV2/qpeit9zX/X1IFAAF9QL/9+j0BO0ZNvIlXX4tAYGxF7385A9C6vgEAEoWHwACAAwA0OvIAPgRCQABE/2tAY2/Io79AQFIAgD0Bff+N64CAvsF/gDKEwb+Cg0FAQCz60F3vxdIZEwAAAAASUVORK5CYII=",
            blurWidth: 8,
            blurHeight: 8
        }
    },
    73743: function(e, t) {
        "use strict";
        t.Z = {
            src: "/_next/static/media/warning_bear.47070f2e.png",
            height: 385,
            width: 385,
            blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABC0lEQVR4nAVAO0vDQBz//a/JNcHEQSE6iI+AOEhBiyBtUamdDHRzEBzUxV0ddRVdnPwiTtJZxFn7ACn1QZG2QQptktocMb1C81MLz80RMpeWKvaNBBkq4UNG8gZJPusrFbKXV6WhEOxeFXYbMAA08isgEeO1xUA7u4XhdPdNyxaPpVB1UhlQebhHbC7hKzYlOfltYbWfeO70FutbBQReH8QSqNfKuLo4B23ksmJT9/jAraIjTJTqPs5ODhF2Gnj8GYKO0mthXwuSasTw/fsHrnGQ10TGOYCIEpJqqcX4DgprTRKUQYTAD/E+Y+HampN7fo/ITdtl/1+mSqTIF51RV0gUR7F0ApcmuPY5BkhzadCB+rXkAAAAAElFTkSuQmCC",
            blurWidth: 8,
            blurHeight: 8
        }
    },
    45638: function(e, t) {
        "use strict";
        t.default = {
            src: "/_next/static/media/error.74bd8204.svg",
            height: 24,
            width: 24,
            blurWidth: 0,
            blurHeight: 0
        }
    },
    10779: function(e, t) {
        "use strict";
        t.default = {
            src: "/_next/static/media/success.f629c4ea.svg",
            height: 24,
            width: 24,
            blurWidth: 0,
            blurHeight: 0
        }
    },
    72745: function(e, t) {
        "use strict";
        t.default = {
            src: "/_next/static/media/warning.d82fe2f3.svg",
            height: 24,
            width: 24,
            blurWidth: 0,
            blurHeight: 0
        }
    }
}]);
